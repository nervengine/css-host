<?xml version="1.0" encoding="UTF-8"?>
<survey 
  alt="ERNEST TEST QUOTA HOOK"
  autosaveKey="rnid,psid,csid"
  browserDupes="safe"
  builder:wizardCompleted="1"
  builderCompatible="1"
  compat="145"
  delphi="1"
  displayOnError="all"
  extraVariables="source,record,ipAddress,decLang,list,userAgent,settings,jumpto,w,isTest,FLAG,c"
  fir="on"
  html:showNumber="0"
  markerTimeout="0"
  mobile="compat"
  mobileDevices="smartphone,tablet,desktop"
  name="Survey"
  remerged="20220614_12:08"
  setup="term,decLang,quota,time"
  spssSimpleCheckbox="1"
  ss:disableBackButton="1"
  ss:enableNavigation="1"
  ss:hideProgressBar="0"
  ss:showBackButton="0"
  state="testing"
  theme="company/theme_dk"
  version="14">

<res label="SCInst" mls="english"><i>Please select one only.</i></res>
<res label="MRInst" mls="english"><i>Please select as many as apply.</i></res>
<res label="SCGInst" mls="english"><i>Please select one answer per row.</i></res>
<res label="MRGInst" mls="english"><i>You can select multiple answers per row but please ensure that each row has at least one answer</i></res>
<res label="SCGcolInst" mls="english"><i>Please select one answer per column.</i></res>
<res label="MRGcolInst" mls="english"><i>You can select multiple answers per column but please ensure that each column has at least one answer</i></res>
<res label="INFInst" mls="english"><i>Please click the Continue button to continue.</i></res>
<res label="OPENInst" mls="english"><i>Please type your answer into the box below</i></res>
<res label="SLIDERInst" mls="english"><i>Please drag the slider to a point on the scale.</i></res>
<res label="CARDInst" mls="english"><i>Place each card into a bucket.</i></res>
<res label="NumInst" mls="english"><i>Please type a number into the box(es) below</i></res>
<res label="SelectInst" mls="english"><i>Please select a option in the drop down below.</i></res>
<res label="RankInst" mls="english"><i>Please rank below options.</i></res>
<res label="IRT_Yes" mls="english">Yes!<br /><b>Hit Z</b></res>
<res label="IRT_No" mls="english">No!<br /><b>Hit M</b></res>
<res label="IRT_Button" mls="english">Click to begin</res>
<res label="IRT_Anykey" mls="english">Please hit any key to begin</res>
<res label="IRT_Complete" mls="english">Please click next to continue.</res>
<res label="IRT_OptionPipe" mls="english"><b><span class="IRTOptionText">...</span></b></res>
<res label="ClientSample_terminated" mls="english">Thank you for taking our survey.</res>
<res label="ClientSample_qualified" mls="english">Thank you for taking our survey. Your efforts are greatly appreciated!</res>
<res label="ClientSample_overquota" mls="english">Thank you for taking our survey.</res>
<res label="Test_terminated" mls="english">Terminated. This page is shown for testing only. Please close the window to exit.</res>
<res label="Test_qualified" mls="english">Qualified. Your efforts are greatly appreciated! This page is shown for testing only. Please close the window to exit.</res>
<res label="Test_overquota" mls="english">Overquota. This page is shown for testing only. Please close the window to exit.</res>
<res label="Jump_terminated" mls="english">(Jump Link - No Panel Source captured) <br /><br /> Terminated</res>
<res label="Jump_qualified" mls="english">(Jump Link - No Panel Source captured) <br /><br /> Qualified</res>
<res label="Jump_overquota" mls="english">(Jump Link - No Panel Source captured) <br /><br /> Overquota</res>
<suspend/>

<note>Res tags for RI - to call use the usual "${res.label}"</note>
<suspend/>

<exec cond="gv.survey.root.state.live">
################### Script to hide BACK button in LIVE survey -- Add "and 0" in cond of exec if need to show BACK button in LIVE survey ###################

gv.survey.root.styles.ss.enableNavigation = 0
</exec>

<suspend/>

<exec when="init">
#D-GUST V2.1.0
#DK settings, set basic and high security keys
#these keys should be changed for every project, please ask your PMs to provide you valid keys for your project
def getDkSecStr():
  try:
    basicKey = 63889 
    highKey = 57863 
    if  basicKey and highKey:
      return "&amp;high=" + str(basicKey * int(pid) - highKey)
    elif basicKey:
      return "&amp;basic=" + str(basicKey)
    else: return ""
  except:
    return ""

xpanelpartner2DB = File("xpanelpartner2.dat", "partnercode")

############################## TEMPLATE UPDATES ###################################
#Thursday, November 25,2021 - Added new partner iPanel (1002). Added translateable="0" to hQualityScoreAnalyze.
#Friday, June 19, 2020 - Updated (Compat 141 - 144)
############################## CUSTOM DEFINES HERE ################################
#CleanQ
def CleanQ(QID):
  try:
    QID.val = None
  except Exception:
    for xrows in QID.rows:
      if xrows:
        xrows.val = 0

#use rowCond="row.label in gMask(this,100,99,'r')"
def gMask(QID,step,stop,kind):
    start = (hidCountry.selected.index + 1) * step + 1
    end = (hidCountry.selected.index + 1) * step + stop
    return ['%s%s' % (kind,x) for x in range(start,end+1)]


def OEvalidation():
  cnt = 0
  answer = 0
  for eachRow in this.rows:
    if eachRow.val:
      answer += 1
    for a in this.rows:
      if (eachRow.index != a.index) and (eachRow and a):
        if eachRow.val.lower() == a.val.lower():
          cnt += 1
    if cnt gt 0:
      error("Duplicate inputs, please check.")
</exec>

<note>-----------------------Quality score-----------------</note>
<note>IMPORTANT NOTE - Please manually add the country that is not found in the Country opion list (example Philppines)</note>
<exec>
#Quality score On/Off, 1 = On, 0 = off
p.qs = dict()
p.qs['on'] = 1;
p.qs['term'] = 1; #Quality score Termination On/Off, 1 = On, 0 = off
 
#Please set Quality Score country code accordingly.
#Please refer to https://confluence.dynata.com/x/WZVKB for the full list of codes.

CountryCode={
 '1':['GB'],  #UK
 '2':['US'],  #USA
 '3':['FR'],  #France
 '4':['IT'],  #Italy
 '5':['DE'],  #Germany
 '6':['ES'],  #Spain
 '7':['SE'],  #Sweden
 '8':['DK'],  #Denmark
 '9':['NO'],  #Norway
'10':['GR'],  #Greece
'11':['HU'],  #Hungary
'12':['CZ'],  #Czech Republic
'13':['PL'],  #Poland
'14':['RU'],  #Russia
'15':['KO'],  #South Korea  - TBC
'16':['TH'],  #Thailand
'17':['GB'],  #UK (Welsh)   - TBC
'18':['IE'],  #Ireland
'19':['AU'],  #Australia
'20':['CN'],  #China
'21':['JP'],  #Japan
'22':['AT'],  #Austria
'23':['IN'],  #India
'24':['TR'],  #Turkey
'25':['AE'],  #UAE
'26':['AR'],  #Argentina
'27':['BR'],  #Brazil
'28':['VE'],  #Venezuela
'29':['CO'],  #Columbia
'30':['CH'],  #Switzerland
'31':['PT'],  #Portugal
'32':['CA'],  #Canada
'33':['MX'],  #Mexico
'34':['MY'],  #Malaysia
'35':['ZA'],  #South Africa
'36':['TN'],  #Tunisia
'37':['BE'],  #Belgium
'38':['NL'],  #Netherlands
'39':['IL'],  #Israel
'40':['SA'],  #Saudi Arabia
'41':['FI'],  #Finland
'42':['NZ'],  #New Zealand
'43':['SG'],  #Singapore
'44':['CL'],  #Chile
'45':['TW'],  #Taiwan
'46':['HK'],  #Hong Kong
'47':['ID']   #Indonesia
}

    
p.qs['countryCode'] = CountryCode[c][0]
#if country code passed by a parameter, e.g. country=CA 

p.qs['surveyID'] = gv.survey.path if gv.survey.root.state.live else gv.survey.path + '_test'
</exec>

<exec>
rnentryurl.val = getFullPath(gv)
start_timestamp.val = long(time.time())

p.rnPanelName = rnGetPanelName(src)
if p.rnPanelName!='': gv.survey.root.styles.ss.logoFile = 'selfserve/dgustlib/logos/' + p.rnPanelName + '_logo.png'


################### Change Survey Logo from here (Remove comment from below and add path of logo) ###################

#gv.survey.root.styles.ss.logoFile = 'selfserve/53b/201903/CHANGE_LOGO.png'
</exec>

<text 
  label="rnentryurl"
  cond="False"
  fwidth="2048"
  size="200"
  translateable="0"
  where="execute,survey,notdp">
  <title>Hidden- to store survey entry url</title>
</text>

<samplesources default="2">
  <samplesource keyring="sys/rn" list="2" sign="out,in">
    <title>neXus/DK</title>
    <invalid>The unique number that tracks your progress through this survey is missing. To resume, please click the original link in the email we sent you.</invalid>
    <completed>It seems you have already entered this survey.</completed>
    <var name="pid" required="1"/>
    <var name="psid" unique="1"/>
    <var name="sp"/>
    <var name="pp"/>
    <var name="sc"/>
    <var name="ppid"/>
    <var name="tm"/>
    <exit cond="terminated and (hasMarker('speederAutoCheck') or hasMarker('speederAuto'))" url="//dkr1.ssisurveys.com/projects/end?rst=2&amp;_d=${gv.survey.path}&amp;psid=${psid}&amp;qflag=1&amp;imperiumQS=${hQualityScoreAnalyze.r1.val}&amp;imperiumQSI=${hQualityScoreAnalyze.r14.val if hQualityScoreAnalyze.r14 else ''}&amp;imperiumQSM=${hQualityScoreAnalyze.r20.val if hQualityScoreAnalyze.r20 else ''}"/>
    <exit cond="terminated and hasMarker('straightlinerAuto')" url="//dkr1.ssisurveys.com/projects/end?rst=2&amp;_d=${gv.survey.path}&amp;psid=${psid}&amp;qflag=25&amp;imperiumQS=${hQualityScoreAnalyze.r1.val}&amp;imperiumQSI=${hQualityScoreAnalyze.r14.val if hQualityScoreAnalyze.r14 else ''}&amp;imperiumQSM=${hQualityScoreAnalyze.r20.val if hQualityScoreAnalyze.r20 else ''}"/>
    <exit cond="terminated and hasMarker('qualityScore')" url="//dkr1.ssisurveys.com/projects/end?rst=2&amp;_d=${gv.survey.path}&amp;psid=${psid}&amp;qflag=95&amp;imperiumQS=${hQualityScoreAnalyze.r1.val}&amp;imperiumQSI=${hQualityScoreAnalyze.r14.val if hQualityScoreAnalyze.r14 else ''}&amp;imperiumQSM=${hQualityScoreAnalyze.r20.val if hQualityScoreAnalyze.r20 else ''}"/>
    <exit cond="terminated and isTest==''" url="//dkr1.ssisurveys.com/projects/end?rst=2&amp;_d=${gv.survey.path}&amp;psid=${psid}${'&amp;qflag=5' if hasMarker('lateScreenOut')  else ''}"/>
    <exit cond="overquota and isTest==''" url="//dkr1.ssisurveys.com/projects/end?rst=3&amp;_d=${gv.survey.path}&amp;psid=${psid}${'&amp;qflag=6' if hasMarker('lateQuotaFull')  else ''}"/>
    <exit cond="qualified and isTest==''" url="//dkr1.ssisurveys.com/projects/end?rst=1&amp;_d=${gv.survey.path}&amp;psid=${psid if gv.survey.root.state.live else psid+'_test'}${getDkSecStr()}${'&amp;compflag=2' if hasMarker('shortComplete') else '&amp;compflag=3' if hasMarker('longComplete')  else ''}&amp;imperiumQS=${hQualityScoreAnalyze.r1.val}&amp;imperiumQSI=${hQualityScoreAnalyze.r14.val if hQualityScoreAnalyze.r14 else ''}&amp;imperiumQSM=${hQualityScoreAnalyze.r20.val if hQualityScoreAnalyze.r20 else ''}"/>
    <exit cond="terminated and isTest=='1'">${res.Test_terminated}</exit>
    <exit cond="qualified and isTest=='1'">${res.Test_qualified}</exit>
    <exit cond="overquota and isTest=='1'">${res.Test_overquota}</exit>
  </samplesource>

  <samplesource list="0">
    <title>Open/Generic Survey</title>
    <invalid>You are missing information in the URL. Please verify the URL with the original invite.</invalid>
    <completed>It seems you have already entered this survey.</completed>
    <var name="csid"/>
    <exit cond="terminated">${res.ClientSample_terminated}</exit>
    <exit cond="qualified">${res.ClientSample_qualified}</exit>
    <exit cond="overquota">${res.ClientSample_overquota}</exit>
  </samplesource>

  <samplesource keyring="sys/rn" list="3" sign="out">
    <title>ConfirmIT Redirect</title>
    <invalid>The unique number that tracks your progress through this survey is missing. To resume, please click the original link in the email we sent you.</invalid>
    <completed>It seems you have already entered this survey.</completed>
    <var name="psid" unique="1"/>
    <var name="src" required="1"/>
    <var name="l"/>
    <var name="csamps"/>
    <var name="csampr"/>
    <var name="csampp"/>
    <exit cond="terminated" url="http://online.ssisurveys.com/wix/${csampp}.aspx?r=${csampr}&amp;s=${csamps}&amp;__qid=iReturn&amp;status=2"/>
    <exit cond="overquota" url="http://online.ssisurveys.com/wix/${csampp}.aspx?r=${csampr}&amp;s=${csamps}&amp;__qid=iReturn&amp;status=3"/>
    <exit cond="qualified" url="http://online.ssisurveys.com/wix/${csampp}.aspx?r=${csampr}&amp;s=${csamps}&amp;__qid=iReturn&amp;status=1"/>
  </samplesource>
</samplesources>

<radio 
  label="SampType"
  cond="tplShow()"
  optional="1"
  randomize="0"
  translateable="0"
  where="execute,survey,report">
  <title>Sample Type</title>
  <exec>
if list=='1':	SampType.val = SampType.r1.index
if list=='2':	SampType.val = SampType.r2.index
if list=='0':	SampType.val = SampType.r3.index
if list=='3':	SampType.val = SampType.r4.index
  </exec>

  <row label="r1" value="1">Research Now (STS UR)</row>
  <row label="r2" value="2">neXus/DK</row>
  <row label="r3" value="3">Open/Generic Survey</row>
  <row label="r4" value="4">ConfirmIT Redirect</row>
</radio>

<suspend/>

<themes>
  <theme cond="p.rnPanelName == 'vop'" name="frozen:company/theme_vop"/>
  <theme cond="p.rnPanelName == 'er'" name="frozen:company/theme_er"/>
  <theme cond="p.rnPanelName == 'mmr'" name="frozen:company/theme_mmr"/>
  <theme cond="list == '2'" name="company/theme_dk"/></themes>
<suspend/>

<style name="global.page.head"><![CDATA[
<script>
jQuery(document).ready(function()
{
	jQuery('.survey-section .footer span:contains("Privacy Policy")').remove();
});
</script>
]]></style>
<suspend/>

<note>Additional security feature to avoid right click in Live survey</note>
<style cond="gv.survey.root.state.live" name="global.page.head"><![CDATA[
<script>
jQuery(document).ready(function()
{
	jQuery.getScript('http://survey-au.researchnow.com/survey/selfserve/dgustlib/res/rnjslib.js?imgsecurity=standard')
});
</script>
]]></style>
<suspend/>

<style mode="after" name="respview.client.css"><![CDATA[
<style type="text/css">
    .autosave-restart { display: none; }
    .grid.grid-table-mode .col-legend { vertical-align: bottom; }
    
    
    
					/* atm1d */

.sq-atm1d-widget .sq-atm1d-button
{
	background-color: transparent;
	border: 2px solid #696a69;
	border-radius: 10px;
	color: #454545;
	font-size: 1.2rem;
}

.sq-atm1d-widget .sq-atm1d-selected, .sq-atm1d-widget .sq-atm1d-hovered
{
	background-color: #5ab414;
	border: transparent;
	color: white;
}


					/* atmtable */

.sq-atmtable-btn 
{
	background-color: transparent !important;
	border: 1px solid #696a69 !important;
	color: #454545 !important;
}

.sq-atmtable-btn-selected, .sq-atmtable-btn-hover
{
	background-color: #5ab414 !important;
	border: transparent !important;
	color: white !important;
}


					/* atmrating */ 

.sq-atmrating-container .atmrating-btn
{
	background-color: transparent !important;
	border: 1px solid #696a69 !important;
	color: #454545 !important;
}

.sq-atmrating-container .atmrating-selected, .sq-atmrating-container .atmrating-hover
{
	background-color: #5ab414 !important;
	color: white !important;
}


					/* cardrating */ 

.sq-cardrating-widget .sq-cardrating-button
{
	background-color: transparent;
	border: 1px solid #696a69;
	color: #454545;
	border-radius: 10px;
	font-size: 1.2rem;
}

.sq-cardrating-widget .sq-cardrating-button[data-hovered]
{
	background-color: #5ab414;
	color: white;
	border: transparent;
}


					/* cardsort */ 

.sq-cardsort .sq-cardsort-bucket
{
	background-color: transparent;
	border: 1px solid #696a69;
	color: #454545;
	border-radius: 10px;
	font-size: 1.2rem;
}

.sq-cardsort .sq-cardsort-bucket:active, div.checkbox .sq-cardsort .sq-cardsort-state-selected:not(.sq-cardsort-card)
{
	background-color: #5ab414;
	color: white;
	border: transparent;
}



					/* ranksort */ 

.sq-ranksort-container .sq-ranksort-card
{
	background-color: transparent !important;
	border: 1px solid #696a69 !important;
	color: #454545 !important;
	font-size: 1.2rem !important;
}

.sq-ranksort-container .sq-ranksort-card:hover, .sq-ranksort-container .sq-ranksort-card-dropped
{
	background-color: #5ab414 !important;
	color: white !important;
}

.sq-ranksort-container .ui-state-disabled
{
	background-color: #EFEFEF !important;
	color: #454545 !important;
	border: transparent !important;
}

.sq-ranksort-container .sq-ranksort-bucket
{
	background-color: #F6F6F6 !important;
	border: 1.5px dashed #888 !important;
}

</style>
]]></style>
<suspend/>

<style cond="decLang in ['hebrew','arabic','arabic_egypt','arabic_lebanon','arabic_morocco','arabic_qatar','arabic_saudiarabia','arabic_uae']" mode="after" name="respview.client.css"><![CDATA[
<style>
 body { direction: rtl; }
 .survey-buttons { text-align: left !important; }
 #surveyContent, .survey-body, .question-text, .instruction-text,
 .grid.grid-table-mode .row-legend, .grid-desktop-mode.grid-list-mode .cell-section,
 .grid-single-col .cell, .grid[data-settings*='single-col'] .cell,
 .noRows .grid.grid.grid-table-mode .colCount-1 .element,
 .noRows .grid.grid.grid-table-mode .colCount-1 .col-legend { text-align: right !important; }
 .survey-body .fir-hidden { left: auto !important; right: -9999px !important; }
</style>
]]></style>
<suspend/>

<block label="blkSurveySettings" builder:title="Survey Settings">
  <note>Survey Defaults - need to be enabled on all projects</note>
  <exec>
try:
  Country.val = Country.attr('r%s' % c).index
except Exception:
  pass
  
#neXus variables
try:
  xsubPanel.val = xsubPanel.attr('r%s' % sp).index
except Exception:
  pass
  
try:
  xpanelPartner.val = xpanelPartner.attr('r%s' % pp).index
except Exception:
  pass
  
#codes below to get and store the panel detail from the File.
#this will be storing "PanelPartnerName (code)" to xpanelPartner2.r1.val

if xpanelpartner2DB.get(pp) != None:
    print xpanelpartner2DB.get(pp)
    dataval = xpanelpartner2DB.get(pp)
    xpanelPartner2.r1.val = dataval['partnername']+" ("+dataval['partnercode']+")"
else: print "WARNING!! Partner not found"
  </exec>

  <radio 
   label="panelSource"
   cond="tplShow()"
   multicol:count="5"
   optional="1"
   randomize="0"
   translateable="0"
   uses="multicol.7"
   where="execute,survey,notdp">
    <title>Identifies which panel the respondent belongs to</title>
    <row label="r1" value="1">VOP UK (United Kingdom)</row>
    <row label="r2" value="2">VOP FR (France)</row>
    <row label="r3" value="3">VOP IT (Italy)</row>
    <row label="r4" value="4">VOP DE (Germany)</row>
    <row label="r5" value="5">VOP ES (Spain)</row>
    <row label="r6" value="6">VOP AU (Australia)</row>
    <row label="r7" value="7">VOP AT (Austria)</row>
    <row label="r8" value="8">VOP NO (Norway)</row>
    <row label="r9" value="9">VOP PL (Poland)</row>
    <row label="r10" value="10">VOP RU (Russia)</row>
    <row label="r11" value="11">VOP IE (Ireland)</row>
    <row label="r12" value="12">VOP CH (Switzerland) - German</row>
    <row label="r13" value="13">VOP DK (Denmark)</row>
    <row label="r14" value="14">VOP FI (Finland)</row>
    <row label="r15" value="15">VOP SE (Sweden)</row>
    <row label="r16" value="16">VOP NL (Netherlands)</row>
    <row label="r17" value="17">VOP GR (Greece)</row>
    <row label="r18" value="18">VOP BE (Belgium) - Dutch</row>
    <row label="r19" value="19">VOP CZ (Czech Rep)</row>
    <row label="r20" value="20">VOP PT (Portugal)</row>
    <row label="r21" value="21">VOP HU (Hungary)</row>
    <row label="r22" value="22">VOP USA (United States) - English</row>
    <row label="r23" value="23">VOP BR (Brazil)</row>
    <row label="r24" value="24">VOP USA (United States) - Spanish</row>
    <row label="r25" value="25">VOP BE (Belgium) - French</row>
    <row label="r26" value="26">VOP CH (Switzerland) - French</row>
    <row label="r27" value="27">VOP CH (Switzerland) - Italian</row>
    <row label="r28" value="28">VOP CH (Switzerland) - English</row>
    <row label="r29" value="29">VOP NZ (New Zealand) - English</row>
    <row label="r30" value="30">VOP ME (Mexico)</row>
    <row label="r31" value="31">VOP IN (India)</row>
    <row label="r32" value="32">VOP CN (China)</row>
    <row label="r33" value="33">VOP SING (Simplified Chinese)</row>
    <row label="r34" value="34">VOP CHIL</row>
    <row label="r35" value="35">VOP SING (English)</row>
    <row label="r36" value="36">VOP ARG</row>
    <row label="r37" value="37">VOP CAN (Canada) - English</row>
    <row label="r38" value="38">VOP CAN (Canada) - French</row>
    <row label="r39" value="39">VOP JAP (Japan)</row>
    <row label="r40" value="40">VOP SKOR (South Korea)</row>
    <row label="r41" value="41">Mum's Opinions</row>
    <row label="r42" value="42">VOP South Africa</row>
    <row label="r43" value="43">B2B UK</row>
    <row label="r44" value="44">Research Now</row>
    <row label="r45" value="45">VOP HK (Chinese)</row>
    <row label="r46" value="46">VOP HK (English)</row>
    <row label="r47" value="47">VOP Taiwan</row>
    <row label="r48" value="48">VOP Malaysia (Malay)</row>
    <row label="r49" value="49">VOP Malaysia (English)</row>
    <row label="r50" value="50">E-Rewards (English)</row>
    <row label="r51" value="51">E-Rewards (Germany)</row>
    <row label="r52" value="52">E-Rewards (Spain)</row>
    <row label="r53" value="53">E-Rewards (France)</row>
    <row label="r54" value="54">E-Rewards (Netherlands)</row>
    <row label="r55" value="55">E-Rewards (Portugal)</row>
    <row label="r56" value="56">E-Rewards MMR</row>
    <row label="r57" value="57">E-Rewards UTB (English)</row>
    <row label="r58" value="58">E-Rewards (Canada-French)</row>
    <row label="r59" value="59">E-Rewards (US-Spanish)</row>
    <row label="r60" value="60">E-Rewards (Mexico-Spanish)</row>
    <row label="r61" value="61">Webmiles DE</row>
    <row label="r62" value="62">Swiss Webmiles DE</row>
    <row label="r63" value="63">Swiss Webmiles FR</row>
    <row label="r64" value="64">VOP Indonesia</row>
    <row label="r65" value="65">VOP Thailand</row>
    <row label="r66" value="66">VOP Turkey</row>
    <row label="r67" value="67">E-Miles</row>
    <row label="r68" value="68">Peanut Labs</row>
    <row label="r69" value="69">AirMiles</row>
    <row label="r70" value="70">Lightspeed North America</row>
    <row label="r71" value="71">Lightspeed Australia</row>
    <row label="r72" value="72">Lightspeed Europe</row>
    <row label="r73" value="73">eRewards</row>
    <row label="r74" value="74">ePocrates</row>
    <row label="r75" value="75">Leger</row>
    <row label="r76" value="76">ToLuna</row>
    <row label="r77" value="77">MedSite</row>
    <row label="r78" value="78">Ipsos</row>
    <row label="r79" value="79">Pureprofile</row>
    <row label="r80" value="80">Ticketekrewards</row>
    <row label="r81" value="81">veda advantage</row>
    <row label="r82" value="82">aussie survey</row>
    <row label="r83" value="83">Ciao</row>
    <row label="r84" value="84">Greenfield</row>
    <row label="r85" value="85">Livra</row>
    <row label="r86" value="86">AIP</row>
    <row label="r87" value="87">GFK</row>
    <row label="r88" value="88">CINT</row>
    <row label="r89" value="89">Livra</row>
    <row label="r90" value="90">Debrand 1</row>
    <row label="r91" value="91">Debrand 2</row>
    <row label="r92" value="92">Debrand 3</row>
    <row label="r93" value="93">Debrand 4</row>
    <row label="r94" value="94">Debrand 5</row>
    <row label="r95" value="95">Debrand 6</row>
    <row label="r96" value="96">Debrand 7</row>
    <row label="r97" value="97">Debrand 8</row>
    <row label="r98" value="98">Debrand 9</row>
    <row label="r99" value="99">CATCH ALL</row>
    <row label="r101" value="101">Nectar Canvass</row>
    <row label="r560" value="560">MMR (EN_UK)</row>
    <row label="r561" value="561">MMR (EN_CA)</row>
    <row label="r562" value="562">MMR (FR_CA)</row>
    <row label="r563" value="563">MMR (DE_DE)</row>
    <row label="r564" value="564">MMR (FR_FR)</row>
    <row label="r565" value="565">MMR (IT_IT)</row>
    <row label="r566" value="566">MMR (ES_ES)</row>
    <row label="r731" value="731">ERI Nectar</row>
  </radio>

  <radio 
   label="Country"
   cond="tplShow()"
   multicol:count="5"
   optional="1"
   randomize="0"
   translateable="0"
   uses="multicol.7"
   where="execute,survey,report">
    <title>Country from URL</title>
    <row label="r1">UK</row>
    <row label="r2">USA</row>
    <row label="r3">France</row>
    <row label="r4">Italy</row>
    <row label="r5">Germany</row>
    <row label="r6">Spain</row>
    <row label="r7">Sweden</row>
    <row label="r8">Denmark</row>
    <row label="r9">Norway</row>
    <row label="r10">Greece</row>
    <row label="r11">Hungary</row>
    <row label="r12">Czech Republic</row>
    <row label="r13">Poland</row>
    <row label="r14">Russia</row>
    <row label="r15">South Korea</row>
    <row label="r16">Thailand</row>
    <row label="r17">UK (Welsh)</row>
    <row label="r18">Ireland</row>
    <row label="r19">Australia</row>
    <row label="r20">China</row>
    <row label="r21">Japan</row>
    <row label="r22">Austria</row>
    <row label="r23">India</row>
    <row label="r24">Turkey</row>
    <row label="r25">UAE</row>
    <row label="r26">Argentina</row>
    <row label="r27">Brazil</row>
    <row label="r28">Venezuela</row>
    <row label="r29">Columbia</row>
    <row label="r30">Switzerland</row>
    <row label="r31">Portugal</row>
    <row label="r32">Canada</row>
    <row label="r33">Mexico</row>
    <row label="r34">Malaysia</row>
    <row label="r35">South Africa</row>
    <row label="r36">Tunisia</row>
    <row label="r37">Belgium</row>
    <row label="r38">Netherlands</row>
    <row label="r39">Israel</row>
    <row label="r40">Saudi Arabia</row>
    <row label="r41">Finland</row>
    <row label="r42">New Zealand</row>
    <row label="r43">Singapore</row>
    <row label="r44">Chile</row>
    <row label="r45">Taiwan</row>
    <row label="r46">Hong Kong</row>
    <row label="r47">Indonesia</row>
  </radio>

  <radio 
   label="xsubPanel"
   cond="tplShow()"
   multicol:count="5"
   optional="1"
   randomize="0"
   translateable="0"
   uses="multicol.7"
   where="execute,survey,notdp">
    <title>DK sub panel. Please add the sub pannels that will be used in this survey.</title>
    <row label="r0" value="0">Respondents without sub panel</row>
  </radio>

  <radio 
   label="xpanelPartner"
   cond="tplShow()"
   multicol:count="5"
   optional="1"
   randomize="0"
   translateable="0"
   uses="multicol.7"
   where="execute,survey,notdp">
    <title>DK panel partner. Please add the panel partners that will be used in this survey.</title>
    <row label="r0" value="0">No external sample provider used</row>
    <row label="r1" value="1">SSI (ePanel)</row>
    <row label="r2" value="2">[Placeholder]</row>
    <row label="r3" value="3">Online Data Collection (ODC)</row>
    <row label="r4" value="4">Respondi for ORD-320197-J9K3</row>
    <row label="r5" value="5">ToLuna - non North America</row>
    <row label="r6" value="6">American Medical</row>
    <row label="r7" value="7">Authentic Response</row>
    <row label="r8" value="8">Amry Research</row>
    <row label="r9" value="9">ARC</row>
    <row label="r10" value="10">BestLife (Spain)</row>
    <row label="r11" value="11">Campus Fundraiser</row>
    <row label="r12" value="12">Canadian Viewpoint (CanView)</row>
    <row label="r13" value="13">Clear Voice Research</row>
    <row label="r14" value="14">Common Knowledge</row>
    <row label="r15" value="15">Cross Tab</row>
    <row label="r16" value="16">Dohring</row>
    <row label="r17" value="17">Focus Forward</row>
    <row label="r18" value="18">Generation Voice</row>
    <row label="r19" value="19">Hispanic Perspective</row>
    <row label="r20" value="20">Ipsos</row>
    <row label="r21" value="21">Market Agent</row>
    <row label="r22" value="22">MDLinx</row>
    <row label="r23" value="23">MyPoints</row>
    <row label="r24" value="24">Pure Profile</row>
    <row label="r25" value="25">Qualibest</row>
    <row label="r26" value="26">Qualified Opinions</row>
    <row label="r27" value="27">ReRez</row>
    <row label="r28" value="28">Sermo</row>
    <row label="r29" value="29">Specpan</row>
    <row label="r30" value="30">Hellenic Research House (HRH)</row>
    <row label="r31" value="31">The Sample Network</row>
    <row label="r32" value="32">uSamp (United Sample)  - no DDR page</row>
    <row label="r33" value="33">Node Research (SayNation set up)</row>
    <row label="r34" value="34">Weekly Reader (WRIndsiders set up)</row>
    <row label="r35" value="35">Western Wats - Opinionology (Opinion Outpost)</row>
    <row label="r36" value="36">CINT</row>
    <row label="r37" value="37">Maktoob Research - English</row>
    <row label="r38" value="38">Lightspeed Research - English</row>
    <row label="r39" value="39">Livra Portuguese - Brazil</row>
    <row label="r40" value="40">Livra - NEW</row>
    <row label="r41" value="41">Livra Spanish - Hispanic countries</row>
    <row label="r42" value="42">SpiderMetrix - Greek</row>
    <row label="r43" value="43">SpiderMetrix - English</row>
    <row label="r44" value="44">Worldwide Panel</row>
    <row label="r45" value="45">Norstat</row>
    <row label="r46" value="46">Userneeds</row>
    <row label="r47" value="47">PanelClix</row>
    <row label="r48" value="48">PeanutLabs</row>
    <row label="r49" value="49">Panel Biz (Maximiles)</row>
    <row label="r50" value="50">Panel Biz (Maximiles)- Austria</row>
    <row label="r51" value="51">Panel Biz (Maximiles)- Switzerland</row>
    <row label="r52" value="52">Socratic</row>
    <row label="r53" value="53">Research by Net</row>
    <row label="r54" value="54">all world (formerly Inquision )</row>
    <row label="r55" value="55">GAIN Inc.</row>
    <row label="r56" value="56">ResearchCenter (Hirek)</row>
    <row label="r57" value="57">Online Market Intelligence (OMI)</row>
    <row label="r58" value="58">COMR</row>
    <row label="r59" value="59">escape</row>
    <row label="r60" value="60">Universal</row>
    <row label="r61" value="61">InterSight</row>
    <row label="r62" value="62">Research Now (OLD - UK)</row>
    <row label="r63" value="63">DubQuest</row>
    <row label="r64" value="64">UThink Online</row>
    <row label="r65" value="65">GFK (Turkey)</row>
    <row label="r66" value="66">Flying Post</row>
    <row label="r67" value="67">ITracks (sample.itracks.com links)</row>
    <row label="r68" value="68">Nextplora</row>
    <row label="r69" value="69">Netquest</row>
    <row label="r70" value="70">Maximiles</row>
    <row label="r71" value="71">[Placeholder]</row>
    <row label="r72" value="72">[Placeholder]</row>
    <row label="r73" value="73">[Placeholder]</row>
    <row label="r74" value="74">[Placeholder]</row>
    <row label="r75" value="75">[Placeholder]</row>
    <row label="r76" value="76">[Placeholder]</row>
    <row label="r77" value="77">Inovaction Research - POLAND</row>
    <row label="r78" value="78">Inovaction Research - CZECH REPUBLIC</row>
    <row label="r79" value="79">Inovaction Research - HUNGARY</row>
    <row label="r80" value="80">Inovaction Research - RUSSIA</row>
    <row label="r81" value="81">Corpscan</row>
    <row label="r82" value="82">AIP Corporation</row>
    <row label="r83" value="83">Borderless Access Panel</row>
    <row label="r84" value="84">Program&amp;Host (Client Sample)</row>
    <row label="r85" value="85">Feedbackme</row>
    <row label="r86" value="86">Maktoob-Arabic</row>
    <row label="r87" value="87">BrianTest</row>
    <row label="r88" value="88">QaTestOnly</row>
    <row label="r89" value="89">KEN_TEST_FS2</row>
    <row label="r90" value="90">[Placeholder]</row>
    <row label="r91" value="91">Mo-web</row>
    <row label="r92" value="92">M3</row>
    <row label="r93" value="93">Stemmark</row>
    <row label="r94" value="94">[Placeholder]</row>
    <row label="r95" value="95">[Placeholder]</row>
    <row label="r96" value="96">WorldOneResearch-leadphysician.com</row>
    <row label="r97" value="97">promio.net GmbH</row>
    <row label="r98" value="98">Aurora Market Research London</row>
    <row label="r99" value="99">Motivaction</row>
    <row label="r100" value="100">GMO Research</row>
    <row label="r101" value="101">GGP</row>
    <row label="r102" value="102">KNOTs Research - BE Flemish</row>
    <row label="r103" value="103">KNOTs Research - BE French</row>
    <row label="r104" value="104">Global Sampling Solutions Inc</row>
    <row label="r105" value="105">GSS</row>
    <row label="r106" value="106">NMS</row>
    <row label="r107" value="107">[Placeholder]</row>
    <row label="r108" value="108">GMI</row>
    <row label="r109" value="109">Quickrewards</row>
    <row label="r110" value="110">DataCollect</row>
    <row label="r111" value="111">uSamp (United Sample) - OLD</row>
    <row label="r112" value="112">Link Research</row>
    <row label="r113" value="113">Zapera</row>
    <row label="r114" value="114">Ciao</row>
    <row label="r115" value="115">Catinet</row>
    <row label="r116" value="116">Pulse Group</row>
    <row label="r117" value="117">Multidados</row>
    <row label="r118" value="118">Interface ASIA-Holden Data (Shanghai)</row>
    <row label="r119" value="119">i-panel</row>
    <row label="r120" value="120">Ivox</row>
    <row label="r121" value="121">The ORU</row>
    <row label="r122" value="122">[Placeholder]</row>
    <row label="r123" value="123">ID Factor</row>
    <row label="r124" value="124">Eksen Research</row>
    <row label="r125" value="125">Blueberries Panel (Australia)</row>
    <row label="r126" value="126">[Placeholder]</row>
    <row label="r127" value="127">Markelytics</row>
    <row label="r128" value="128">Epocrates</row>
    <row label="r129" value="129">ClearVoice - no DDR Page</row>
    <row label="r130" value="130">Greenfield Online</row>
    <row label="r131" value="131">Embrain (KR)</row>
    <row label="r132" value="132">Hiving (Panoranet)</row>
    <row label="r133" value="133">Elogia</row>
    <row label="r134" value="134">Easy Panel</row>
    <row label="r135" value="135">SWG</row>
    <row label="r136" value="136">Holden data (Interface ASIA)</row>
    <row label="r137" value="137">Panel Insight</row>
    <row label="r138" value="138">Freesurveys</row>
    <row label="r139" value="139">e-Rewards</row>
    <row label="r140" value="140">ToLuna - US &amp; CA</row>
    <row label="r141" value="141">Great UK Surveys</row>
    <row label="r142" value="142">Hiving</row>
    <row label="r143" value="143">Eye click</row>
    <row label="r144" value="144">JTN Research</row>
    <row label="r145" value="145">Omirussia</row>
    <row label="r146" value="146">ePanel</row>
    <row label="r147" value="147">Empathy Research/Pigsback Panel</row>
    <row label="r148" value="148">Digitieto</row>
    <row label="r149" value="149">Sundae</row>
    <row label="r150" value="150">CARI</row>
    <row label="r151" value="151">Viewsclub</row>
    <row label="r152" value="152">IMAS</row>
    <row label="r153" value="153">IID Korea</row>
    <row label="r154" value="154">My Opinions</row>
    <row label="r155" value="155">Mediana</row>
    <row label="r156" value="156">The Great Australian Survey (GAS)</row>
    <row label="r157" value="157">Kiwi Surveys (GAS)</row>
    <row label="r158" value="158">Multiscope</row>
    <row label="r159" value="159">Offerwise</row>
    <row label="r160" value="160">Research Panel Japan</row>
    <row label="r161" value="161">Rohan</row>
    <row label="r162" value="162">OI Research</row>
    <row label="r163" value="163">Creating Internet Business</row>
    <row label="r164" value="164">Panelbase</row>
    <row label="r165" value="165">IDiaoYan</row>
    <row label="r166" value="166">QPA</row>
    <row label="r167" value="167">Yougov</row>
    <row label="r168" value="168">Q&amp;A</row>
    <row label="r169" value="169">Inzicht Marktonderzoek</row>
    <row label="r170" value="170">Iconoculture Adult</row>
    <row label="r171" value="171">pluggedinnatio</row>
    <row label="r172" value="172">Hyphens!</row>
    <row label="r173" value="173">Novio Data</row>
    <row label="r174" value="174">Sus Opiniones(Do not use)</row>
    <row label="r175" value="175">SUS OPINIONES</row>
    <row label="r176" value="176">EMI</row>
    <row label="r177" value="177">Luth Research</row>
    <row label="r178" value="178">Public Opinions</row>
    <row label="r179" value="179">Inovaction Research - ROMANIA</row>
    <row label="r180" value="180">ROI Rocket</row>
    <row label="r181" value="181">Insight Xplorer</row>
    <row label="r182" value="182">EOL Embrain (TW)</row>
    <row label="r183" value="183">OMI Vietnam</row>
    <row label="r184" value="184">Telkomsa (formerly known as Skopos)</row>
    <row label="r185" value="185">Healthcare landscape</row>
    <row label="r186" value="186">Research Panel China</row>
    <row label="r187" value="187">GMRG</row>
    <row label="r188" value="188">Delvinia</row>
    <row label="r189" value="189">MindField (McMillon)</row>
    <row label="r190" value="190">Empowered Communications</row>
    <row label="r191" value="191">Inovaction Research - BULGARIA</row>
    <row label="r192" value="192">empanel (No longer in use)</row>
    <row label="r193" value="193">empanel (surveyhub)</row>
    <row label="r194" value="194">Estima</row>
    <row label="r195" value="195">MAP-MR</row>
    <row label="r196" value="196">Futuremarketing</row>
    <row label="r197" value="197">Opinion Place</row>
    <row label="r198" value="198">Yoursay</row>
    <row label="r199" value="199">MBA Recherche</row>
    <row label="r200" value="200">UKnursing.net</row>
    <row label="r201" value="201">Doctors.net.uk</row>
    <row label="r202" value="202">Viadeo</row>
    <row label="r203" value="203">TICKETEK INSIGHTS ninerewards.co.nz</row>
    <row label="r204" value="204">Clevelresearch</row>
    <row label="r205" value="205">[Placeholder]</row>
    <row label="r206" value="206">Panel Services Africa (previously known as: Marketing Sciences)</row>
    <row label="r207" value="207">Research Panel South Korea</row>
    <row label="r208" value="208">Paradigm</row>
    <row label="r209" value="209">WebMD</row>
    <row label="r210" value="210">Garcia Research (Knowledge Networks)</row>
    <row label="r211" value="211">Response Analyse</row>
    <row label="r212" value="212">Mindtake</row>
    <row label="r213" value="213">iPanelOnline_New</row>
    <row label="r214" value="214">INTEGRAL Markt- und Meinungsforschungsges.m.b.H.</row>
    <row label="r215" value="215">Sondageo</row>
    <row label="r216" value="216">SampleBus</row>
    <row label="r217" value="217">Datatelligence</row>
    <row label="r218" value="218">Netetude</row>
    <row label="r219" value="219">RNB Research</row>
    <row label="r220" value="220">Hirek Media</row>
    <row label="r221" value="221">Klaster Research</row>
    <row label="r222" value="222">CONVERGE ICT SOLUTIONS &amp; SERVICES S.A.</row>
    <row label="r223" value="223">Daedalus New Media Research</row>
    <row label="r224" value="224">Holden Pearmain</row>
    <row label="r225" value="225">Holden Pearmain</row>
    <row label="r226" value="226">Meinungsraum</row>
    <row label="r227" value="227">Opinionology (Opinion Outpost/Western Wats)</row>
    <row label="r228" value="228">UMA</row>
    <row label="r229" value="229">Linkedin</row>
    <row label="r230" value="230">Panel on the web</row>
    <row label="r231" value="231">Offerwise Hispanic (Que Opinas)</row>
    <row label="r232" value="232">Epinion -cint.com</row>
    <row label="r233" value="233">Centron</row>
    <row label="r234" value="234">Research Results (CVS)</row>
    <row label="r235" value="235">Lab42</row>
    <row label="r236" value="236">Online Solutions</row>
    <row label="r237" value="237">Dubit Limited</row>
    <row label="r238" value="238">Exevo</row>
    <row label="r239" value="239">iPanelOnline</row>
    <row label="r240" value="240">Research Bods</row>
    <row label="r241" value="241">MMR</row>
    <row label="r242" value="242">DBS (Datamarketing)</row>
    <row label="r243" value="243">springvaleonline</row>
    <row label="r244" value="244">GoldMind</row>
    <row label="r245" value="245">Opinionpanel</row>
    <row label="r246" value="246">Leger Marketing</row>
    <row label="r247" value="247">Dorinsight</row>
    <row label="r248" value="248">Vision Critical</row>
    <row label="r249" value="249">Globus Consulting &amp; Research</row>
    <row label="r250" value="250">Inovaction Research - SLOVAKIA</row>
    <row label="r251" value="251">Precision Sample</row>
    <row label="r252" value="252">MediResource (English)</row>
    <row label="r253" value="253">MediResource (French)</row>
    <row label="r254" value="254">Olson</row>
    <row label="r255" value="255">NexCura</row>
    <row label="r256" value="256">Winning Research</row>
    <row label="r257" value="257">EC Global Panel (ecglobalpanel.com links)</row>
    <row label="r258" value="258">Tiburon-Research</row>
    <row label="r259" value="259">QQSurvey China Online research</row>
    <row label="r260" value="260">PMI-Korea (Tillion panel)</row>
    <row label="r261" value="261">OMNI</row>
    <row label="r262" value="262">Sample Strategies</row>
    <row label="r263" value="263">Macromill</row>
    <row label="r264" value="264">SingPost</row>
    <row label="r265" value="265">All Global</row>
    <row label="r266" value="266">OMR</row>
    <row label="r267" value="267">Reinvention</row>
    <row label="r268" value="268">interresearch</row>
    <row label="r269" value="269">igi Market Care</row>
    <row label="r270" value="270">Federated Sample</row>
    <row label="r271" value="271">Universal Survey</row>
    <row label="r272" value="272">VGMarket Surveys</row>
    <row label="r273" value="273">Reckner</row>
    <row label="r274" value="274">Opinion Health</row>
    <row label="r275" value="275">MediaResearch CZ</row>
    <row label="r276" value="276">MediaResearch SK</row>
    <row label="r277" value="277">LARC</row>
    <row label="r278" value="278">SSI - RTR</row>
    <row label="r279" value="279">Inovaction Research - UKRAINE</row>
    <row label="r280" value="280">Inovaction Research - LITHUANIA</row>
    <row label="r281" value="281">Hugo Dunhill Mailing Lists</row>
    <row label="r282" value="282">Market Dimensions</row>
    <row label="r283" value="283">Inquision</row>
    <row label="r284" value="284">COMR (France site)</row>
    <row label="r285" value="285">Apac Partner Test</row>
    <row label="r286" value="286">Focus Pointe</row>
    <row label="r287" value="287">ViewsTap</row>
    <row label="r288" value="288">Med Query</row>
    <row label="r289" value="289">Questionnaire India</row>
    <row label="r290" value="290">Q&amp;A Research&amp;Consultancy</row>
    <row label="r291" value="291">YouMint</row>
    <row label="r292" value="292">Data Collect SLOVAKIA</row>
    <row label="r293" value="293">IPSOS (OTX)</row>
    <row label="r294" value="294">Czech National Panel (Stemmark)</row>
    <row label="r295" value="295">TNS Ilres</row>
    <row label="r296" value="296">MISCO Consulting</row>
    <row label="r297" value="297">ConRead Research Bureau Ltd</row>
    <row label="r298" value="298">Proximity</row>
    <row label="r299" value="299">3d Interactive</row>
    <row label="r300" value="300">Marketing VF (Moodia)</row>
    <row label="r301" value="301">Panel4All</row>
    <row label="r302" value="302">SWAT</row>
    <row label="r303" value="303">SurveyMy Data Collection</row>
    <row label="r304" value="304">WorldOneResearch-onesurvey.com</row>
    <row label="r305" value="305">CG Selecties</row>
    <row label="r306" value="306">OP4G</row>
    <row label="r307" value="307">Surveymy Data Collection Sdn. Bhd.</row>
    <row label="r308" value="308">Epinion-respomondo</row>
    <row label="r309" value="309">YouGov 2</row>
    <row label="r310" value="310">Internet Research Bureau Pvt. Ltd.</row>
    <row label="r311" value="311">KutatoCentrum Online</row>
    <row label="r312" value="312">Middle Quality Co., LTD</row>
    <row label="r313" value="313">Marketlink</row>
    <row label="r314" value="314">Insightsource</row>
    <row label="r315" value="315">Genmarc Research</row>
    <row label="r316" value="316">Research Now (medical.com end links)</row>
    <row label="r317" value="317">Data100</row>
    <row label="r318" value="318">Unister UMA</row>
    <row label="r319" value="319">Fine Panel Brazil</row>
    <row label="r320" value="320">TICKETEK INSIGHTS ninerewards.com.au</row>
    <row label="r321" value="321">Embrain Ver2 (KR)</row>
    <row label="r322" value="322">Strat Agile</row>
    <row label="r323" value="323">IBCOC</row>
    <row label="r324" value="324">Horizon Research Limited</row>
    <row label="r325" value="325">EC Global Panel (www.eckrm.com links)</row>
    <row label="r326" value="326">Direction Research</row>
    <row label="r327" value="327">NRC Market Research</row>
    <row label="r328" value="328">Paneland Market Research</row>
    <row label="r329" value="329">M3 (survey.euro.confirmit.com)</row>
    <row label="r330" value="330">Panel Biz (Maximiles-France)</row>
    <row label="r331" value="331">Esearch</row>
    <row label="r332" value="332">Harris Poll Online</row>
    <row label="r333" value="333">Focus Suites UAE</row>
    <row label="r334" value="334">Focus Suites KSA</row>
    <row label="r335" value="335">Focus Suites India</row>
    <row label="r336" value="336">Manthan Software Services</row>
    <row label="r337" value="337">Stemmark-Czech National Panel (Slovakia links)</row>
    <row label="r338" value="338">Schlesinger Associates</row>
    <row label="r339" value="339">uSamp (United Sample)</row>
    <row label="r340" value="340">For Supply Team Only-Paneland Certification</row>
    <row label="r341" value="341">3 Dimension Interactive Pty Ltd  3D Ver2(AU)</row>
    <row label="r342" value="342">[Placeholder]</row>
    <row label="r343" value="343">Avante</row>
    <row label="r344" value="344">Knowledge Networks</row>
    <row label="r345" value="345">The Logit Group</row>
    <row label="r346" value="346">Online Research Panel</row>
    <row label="r347" value="347">Panelclix static</row>
    <row label="r348" value="348">[Placeholder]</row>
    <row label="r349" value="349">PermissionCorp Pty Ltd</row>
    <row label="r350" value="350">ORD-71727 client sample</row>
    <row label="r351" value="351">Pamiclub- Seoul Marketing Research</row>
    <row label="r352" value="352">Promio2</row>
    <row label="r353" value="353">MROptimus</row>
    <row label="r354" value="354">Mediana 2</row>
    <row label="r355" value="355">Rakuten Research</row>
    <row label="r356" value="356">CommunityView Services</row>
    <row label="r357" value="357">Research Now US</row>
    <row label="r358" value="358">Quickrewards_BL</row>
    <row label="r359" value="359">InQuest Market Research</row>
    <row label="r360" value="360">Research for Good</row>
    <row label="r361" value="361">GMO Research-Generic</row>
    <row label="r362" value="362">Eniro Danmark A/S</row>
    <row label="r363" value="363">Clear Voice Research(ROI)</row>
    <row label="r364" value="364">TeamRecrut</row>
    <row label="r365" value="365">Wilke</row>
    <row label="r366" value="366">Mixi Research</row>
    <row label="r367" value="367">Synapse</row>
    <row label="r368" value="368">Insight CN</row>
    <row label="r369" value="369">Points2Shop_1486</row>
    <row label="r370" value="370">Lucky Pacific</row>
    <row label="r371" value="371">MBA Recherche 2</row>
    <row label="r372" value="372">Market Inside-Quality Co., Ltd</row>
    <row label="r373" value="373">Doctor Directory</row>
    <row label="r374" value="374">The Human Network</row>
    <row label="r375" value="375">Harris Interactive (Federated)</row>
    <row label="r376" value="376">Stable Research</row>
    <row label="r377" value="377">Daedalus New Media Research-NEW</row>
    <row label="r378" value="378">INV Marketing Research</row>
    <row label="r379" value="379">INV_Marketing Research</row>
    <row label="r380" value="380">3 Dimension Interactive Pty Ltd  3D ver_3(NZ)</row>
    <row label="r381" value="381">Delvinia EU</row>
    <row label="r382" value="382">Minder</row>
    <row label="r383" value="383">Minder EU</row>
    <row label="r384" value="384">Multiscope Ver2</row>
    <row label="r385" value="385">Aurora Market Research London_new</row>
    <row label="r386" value="386">Inovaction Research-LITHUANIA</row>
    <row label="r387" value="387">Yellow Squares</row>
    <row label="r388" value="388">ORD-93699</row>
    <row label="r389" value="389">104 survey</row>
    <row label="r390" value="390">Offerwise/Varsityplaza</row>
    <row label="r391" value="391">Temp--Borderless Access Panel</row>
    <row label="r392" value="392">eMax Research</row>
    <row label="r393" value="393">Critical Mix</row>
    <row label="r394" value="394">Critical Mix/Reinvention</row>
    <row label="r395" value="395">ITG Healthcare Market Research</row>
    <row label="r396" value="396">Majestic MRSS</row>
    <row label="r397" value="397">Cross Tab(RN)</row>
    <row label="r398" value="398">Research Now (temp e-Rewards)</row>
    <row label="r399" value="399">Exafield</row>
    <row label="r400" value="400">CONECTA</row>
    <row label="r401" value="401">Insights West</row>
    <row label="r402" value="402">APAC-Market Inside-Quality Co., Ltd</row>
    <row label="r403" value="403">SDS (Sina Data Solution)</row>
    <row label="r404" value="404">Research now Temp e-Rewards(AirMiles)</row>
    <row label="r405" value="405">Critical mix version 2</row>
    <row label="r406" value="406">Cido Research</row>
    <row label="r407" value="407">Opinaiapanel</row>
    <row label="r408" value="408">I-View</row>
    <row label="r409" value="409">Online solutions(new redirects)</row>
    <row label="r410" value="410">Imperative Research</row>
    <row label="r411" value="411">[Placeholder]</row>
    <row label="r412" value="412">Borderless - communisense</row>
    <row label="r413" value="413">Berent</row>
    <row label="r414" value="414">JP use only-GFK Custom Research KK</row>
    <row label="r415" value="415">Czech National Panel (Czech Republic)</row>
    <row label="r416" value="416">Novel Research</row>
    <row label="r417" value="417">Mislim, torej sem / Fluid panels</row>
    <row label="r418" value="418">Apsidata Solutions</row>
    <row label="r419" value="419">Genpop Online</row>
    <row label="r420" value="420">Dientong Marketing</row>
    <row label="r421" value="421">Meinungsraum(New)</row>
    <row label="r422" value="422">72Points</row>
    <row label="r423" value="423">One Poll</row>
    <row label="r424" value="424">Noviodata (Toluna redirects)</row>
    <row label="r425" value="425">EasyInsites</row>
    <row label="r426" value="426">Fine Panel other Spanish countries</row>
    <row label="r427" value="427">HoldenData (Interface Asia) CN</row>
    <row label="r428" value="428">Decision Point Research</row>
    <row label="r429" value="429">PureProfile 2</row>
    <row label="r430" value="430">QuidCo</row>
    <row label="r431" value="431">Think Now Research</row>
    <row label="r432" value="432">Genmarc Research CRC</row>
    <row label="r433" value="433">Precision Sample (precisionsample.com)</row>
    <row label="r434" value="434">Chongqing KuYuan</row>
    <row label="r435" value="435">CINT Ver2</row>
    <row label="r436" value="436">Peanut Labs Samplify</row>
    <row label="r437" value="437">Market Cube</row>
    <row label="r438" value="438">RTS</row>
    <row label="r439" value="439">Borders Singapore</row>
    <row label="r440" value="440">Borders Philippines</row>
    <row label="r441" value="441">Borders Indonesia</row>
    <row label="r442" value="442">Borders Malaysia</row>
    <row label="r443" value="443">Borders Vietnam</row>
    <row label="r444" value="444">Borders Thailand</row>
    <row label="r445" value="445">CINT re-directs</row>
    <row label="r446" value="446">SWAT version 2</row>
    <row label="r447" value="447">Netquest-Nice</row>
    <row label="r448" value="448">Schmiedl Marktforschung</row>
    <row label="r449" value="449">Opinion Route</row>
    <row label="r450" value="450">RUISI</row>
    <row label="r451" value="451">FashionPlaytes</row>
    <row label="r452" value="452">Gosurvey</row>
    <row label="r453" value="453">Decision Analyst</row>
    <row label="r454" value="454">Soap Box</row>
    <row label="r455" value="455">Inovaction Research - Estonia</row>
    <row label="r456" value="456">Inovaction Research - Latvia</row>
    <row label="r457" value="457">Inovaction Research -Estonia</row>
    <row label="r458" value="458">CZ National Panel (Slovakia)</row>
    <row label="r459" value="459">QQFS</row>
    <row label="r460" value="460">SwagBucks</row>
    <row label="r461" value="461">Sample vibe</row>
    <row label="r462" value="462">Research Bods2</row>
    <row label="r463" value="463">uSamp True Sample Links</row>
    <row label="r464" value="464">GNN Research India</row>
    <row label="r465" value="465">GNN Research KSA</row>
    <row label="r466" value="466">Netetude UK</row>
    <row label="r467" value="467">Panthera</row>
    <row label="r468" value="468">Online Research Panel-Certification Malaysia</row>
    <row label="r469" value="469">Online Research Panel-Certification English</row>
    <row label="r470" value="470">MyPoints (www.samplicio.us)</row>
    <row label="r471" value="471">Survey Pacific</row>
    <row label="r472" value="472">GapFish</row>
    <row label="r473" value="473">GapFish CH</row>
    <row label="r474" value="474">Research Now v2</row>
    <row label="r475" value="475">YourWord</row>
    <row label="r476" value="476">NTTCom</row>
    <row label="r477" value="477">PureProfile quidco-opinions</row>
    <row label="r478" value="478">Schlesinger Associates_2</row>
    <row label="r479" value="479">Offerwise V.2</row>
    <row label="r480" value="480">temp ORD-115512-TY89</row>
    <row label="r481" value="481">Asking Canadians</row>
    <row label="r482" value="482">Genmarc Research New</row>
    <row label="r483" value="483">Genmarc 2</row>
    <row label="r484" value="484">Genmarc</row>
    <row label="r485" value="485">ClearVoice New</row>
    <row label="r486" value="486">Orchidea Research</row>
    <row label="r487" value="487">Student Edge</row>
    <row label="r488" value="488">Manthan M-Panels</row>
    <row label="r489" value="489">Moodia New</row>
    <row label="r490" value="490">GapFish-FR</row>
    <row label="r491" value="491">Ipsos 2</row>
    <row label="r492" value="492">Facts &amp; Factors Marketing Research</row>
    <row label="r493" value="493">Annik</row>
    <row label="r494" value="494">Opinionsbridge(HK)</row>
    <row label="r495" value="495">VN Market Research</row>
    <row label="r496" value="496">Innovate</row>
    <row label="r497" value="497">Aristos Erevna Consulting</row>
    <row label="r498" value="498">Data Collect CZ</row>
    <row label="r499" value="499">Peanut Labs Samplify_2</row>
    <row label="r500" value="500">MoWeb IKEA</row>
    <row label="r501" value="501">YouthSight</row>
    <row label="r502" value="502">TrendResearch</row>
    <row label="r503" value="503">Robas Research SK</row>
    <row label="r504" value="504">Robas Research AU</row>
    <row label="r505" value="505">Asia Opinions</row>
    <row label="r506" value="506">Luth Research v2</row>
    <row label="r507" value="507">Reward Craze</row>
    <row label="r508" value="508">Research Runner</row>
    <row label="r509" value="509">Hanley Wood</row>
    <row label="r510" value="510">YouGov 3</row>
    <row label="r511" value="511">Innovate EU</row>
    <row label="r512" value="512">Dakia Online</row>
    <row label="r513" value="513">Research Runner USA</row>
    <row label="r514" value="514">Panelbiz(Maximiles) New</row>
    <row label="r515" value="515">Opinionsbridge(CN)</row>
    <row label="r516" value="516">Student Edge Ver2</row>
    <row label="r517" value="517">InnovateMR</row>
    <row label="r518" value="518">Research Now v3</row>
    <row label="r519" value="519">NTUC Link</row>
    <row label="r520" value="520">Vindale Media, LLC</row>
    <row label="r521" value="521">On Device</row>
    <row label="r522" value="522">Harris Interactive 2</row>
    <row label="r523" value="523">Glocal Mind</row>
    <row label="r524" value="524">TNS NZ SmileCity Panel</row>
    <row label="r525" value="525">Opinium Research LLP</row>
    <row label="r526" value="526">MyOpinions-NZ</row>
    <row label="r527" value="527">[Placeholder]</row>
    <row label="r528" value="528">Mindtake AT</row>
    <row label="r529" value="529">Mindtake AT Recontact</row>
    <row label="r530" value="530">Tap Research</row>
    <row label="r531" value="531">Inovaction Slovakia</row>
    <row label="r532" value="532">Medefield America</row>
    <row label="r533" value="533">Opinionbridge2</row>
    <row label="r534" value="534">Empathy Research/Pigsback Panel_2</row>
    <row label="r535" value="535">Xsights</row>
    <row label="r536" value="536">Branded Research Inc</row>
    <row label="r537" value="537">Public Opinions_2</row>
    <row label="r538" value="538">NetQuest_2</row>
    <row label="r539" value="539">Marketing Sciences Ltd</row>
    <row label="r540" value="540">Valicon</row>
    <row label="r541" value="541">Absolut Data Intelligent Analytics</row>
    <row label="r542" value="542">Inovaction Research - ROMANIA2</row>
    <row label="r543" value="543">ClearVoice Use</row>
    <row label="r544" value="544">Idiaoyan - certification</row>
    <row label="r545" value="545">IP Deutschland</row>
    <row label="r546" value="546">IP Deutschland GMBH</row>
    <row label="r547" value="547">InterSight 2</row>
    <row label="r548" value="548">nQuire China Research Ltd</row>
    <row label="r549" value="549">SWAT 3</row>
    <row label="r550" value="550">Else Care</row>
    <row label="r551" value="551">Opinionsbridge (MY)</row>
    <row label="r552" value="552">JP only-MT(ToLuna)</row>
    <row label="r553" value="553">Quality Online Research (QOR)</row>
    <row label="r554" value="554">QQ Survey</row>
    <row label="r555" value="555">Student Edge_ver3</row>
    <row label="r556" value="556">Prodege</row>
    <row label="r557" value="557">OMR GlobUS inc</row>
    <row label="r558" value="558">biNu Pty Ldt</row>
    <row label="r559" value="559">Branded Research EU</row>
    <row label="r560" value="560">Wise Sample</row>
    <row label="r561" value="561">W&amp;S Company -VN</row>
    <row label="r562" value="562">Cross Marketing</row>
    <row label="r563" value="563">Mums Views</row>
    <row label="r564" value="564">Kadence</row>
    <row label="r565" value="565">Mercury Magazines</row>
    <row label="r566" value="566">MARSH Co.,Ltd.</row>
    <row label="r567" value="567">Gradible</row>
    <row label="r568" value="568">Market Cube for TRUE SAMPLE</row>
    <row label="r569" value="569">Gradible EU</row>
    <row label="r570" value="570">worldwide</row>
    <row label="r571" value="571">Blauw</row>
    <row label="r572" value="572">Schlesinger Active</row>
    <row label="r573" value="573">EDS Serv Ltd</row>
    <row label="r574" value="574">Field Global</row>
    <row label="r575" value="575">Gapfish Gallup Austria</row>
    <row label="r576" value="576">Freemount Midia Ltda</row>
    <row label="r577" value="577">ESD SERVICES LIMITED</row>
    <row label="r578" value="578">OP Vision</row>
    <row label="r579" value="579">Markteffect</row>
    <row label="r580" value="580">Panelclix BE-NL</row>
    <row label="r581" value="581">Research MEA</row>
    <row label="r582" value="582">Empowered Communications (2)</row>
    <row label="r583" value="583">Glocal Mind 2</row>
    <row label="r584" value="584">NZ-PermissionCorp Pty Ltd</row>
    <row label="r585" value="585">Bilendi Finland</row>
    <row label="r586" value="586">Bilendi Sweden</row>
    <row label="r587" value="587">Opinions and Rewards</row>
    <row label="r588" value="588">Opinionsbridge(SG)</row>
    <row label="r589" value="589">Precision Opinion</row>
    <row label="r590" value="590">AU-Researchpanel pty ltd</row>
    <row label="r591" value="591">Noviodata New</row>
    <row label="r592" value="592">Inovaction Greece</row>
    <row label="r593" value="593">Wise Sample (V2)</row>
    <row label="r594" value="594">Survata</row>
    <row label="r595" value="595">Iresearch Services</row>
    <row label="r596" value="596">Sample bus</row>
    <row label="r597" value="597">Go Web Surveys</row>
    <row label="r598" value="598">Gapfish New</row>
    <row label="r599" value="599">Ireach</row>
    <row label="r600" value="600">Gapfish DE</row>
    <row label="r601" value="601">DO NOT USE ORD177894 GMI via Crosstab</row>
    <row label="r602" value="602">M-Telligent (Thailand)</row>
    <row label="r603" value="603">M-Telligent (Hong Kong)</row>
    <row label="r604" value="604">Aurora 2</row>
    <row label="r605" value="605">NTUC 2</row>
    <row label="r606" value="606">Rare Patient Voice</row>
    <row label="r607" value="607">YURONG CORPORATION</row>
    <row label="r608" value="608">ForJP-ToLuna</row>
    <row label="r609" value="609">ForJP-Research Now v4</row>
    <row label="r610" value="610">Laba (Shanghai) Technology Co., Ltd.</row>
    <row label="r611" value="611">Research Panel Hong Kong</row>
    <row label="r612" value="612">DO NOT USE - Supply USE ONLY-IX</row>
    <row label="r613" value="613">JTN new</row>
    <row label="r614" value="614">Afrovas</row>
    <row label="r615" value="615">Leger Marketing-English</row>
    <row label="r616" value="616">Leger Marketing-French (JP office only)</row>
    <row label="r617" value="617">Aurora New</row>
    <row label="r618" value="618">APD Performance (former Empowered)</row>
    <row label="r619" value="619">Norstat 2</row>
    <row label="r620" value="620">ARC 2</row>
    <row label="r621" value="621">Eedo</row>
    <row label="r622" value="622">Voices Africa</row>
    <row label="r623" value="623">GapFish AT</row>
    <row label="r624" value="624">Research Now (OLD)</row>
    <row label="r625" value="625">Research Now New2</row>
    <row label="r626" value="626">Global Research Services</row>
    <row label="r627" value="627">Dataction(Cup.li)</row>
    <row label="r628" value="628">Columinate</row>
    <row label="r629" value="629">Affordable Samples</row>
    <row label="r630" value="630">Cox Research</row>
    <row label="r631" value="631">Specpan Version 2</row>
    <row label="r632" value="632">Market/sampling cube DO NOT USE AS OF 4.4.2017</row>
    <row label="r633" value="633">[Placeholder]</row>
    <row label="r634" value="634">Ver 2-AU-Researchpanel pty ltd</row>
    <row label="r635" value="635">Direction First</row>
    <row label="r636" value="636">Opinionsbridge (CN) 2</row>
    <row label="r637" value="637">Research Now Ver5</row>
    <row label="r638" value="638">NTUC Type 3</row>
    <row label="r639" value="639">InnovateV2</row>
    <row label="r640" value="640">YourSource</row>
    <row label="r641" value="641">WiT Works consulting</row>
    <row label="r642" value="642">Intra Research (Baltic Panels) Latvia</row>
    <row label="r643" value="643">Offer-WOW</row>
    <row label="r644" value="644">Voices Africa Kenya</row>
    <row label="r645" value="645">Voices Africa Nigeria</row>
    <row label="r646" value="646">AIP-Rakuten</row>
    <row label="r647" value="647">DO NOT USE – Supply USE ONLY – APD NZ</row>
    <row label="r648" value="648">Sponge IT</row>
    <row label="r649" value="649">Ekas</row>
    <row label="r650" value="650">NextOn Services</row>
    <row label="r651" value="651">Ricca Group</row>
    <row label="r652" value="652">W&amp;S Company -ID</row>
    <row label="r653" value="653">Persona.ly</row>
    <row label="r654" value="654">DO NOT USE-i-Link Research Solutions Pty Ltd</row>
    <row label="r655" value="655">Dalia</row>
    <row label="r656" value="656">i-Link Research Solutions Pty Ltd</row>
    <row label="r657" value="657">Toluna version 2</row>
    <row label="r658" value="658">Noviodata new redirects</row>
    <row label="r659" value="659">DianDianZhuan</row>
    <row label="r660" value="660">MKS RESEARCH</row>
    <row label="r661" value="661">CONSUMED RESEARCH</row>
    <row label="r662" value="662">Integrity Market Research (IMR)</row>
    <row label="r663" value="663">innoPoll</row>
    <row label="r664" value="664">Garcia Research (Knowledge Networks) version 2</row>
    <row label="r665" value="665">VodaFone</row>
    <row label="r666" value="666">Green Apple Research (Data Diggers)</row>
    <row label="r667" value="667">Sponge IT_2</row>
    <row label="r668" value="668">Market Cube</row>
    <row label="r669" value="669">Tiburon New</row>
    <row label="r670" value="670">Sellbuy</row>
    <row label="r671" value="671">Patientsworld</row>
    <row label="r672" value="672">iResearch v.1</row>
    <row label="r673" value="673">qandaresearch</row>
    <row label="r674" value="674">Interactive MR</row>
    <row label="r675" value="675">PureProfile 3</row>
    <row label="r676" value="676">Mindtake AT Recontact_2</row>
    <row label="r677" value="677">Conclave Research</row>
    <row label="r678" value="678">Elicit Research</row>
    <row label="r679" value="679">Ampersandata</row>
    <row label="r680" value="680">DO NOT USE--CONG TY TNHH AP VIETNAM</row>
    <row label="r681" value="681">Link New</row>
    <row label="r682" value="682">Sermo V.2</row>
    <row label="r683" value="683">Daedalus IKEA Redirects</row>
    <row label="r684" value="684">Spidermetrix New</row>
    <row label="r685" value="685">Beijing Mingchashenglue</row>
    <row label="r686" value="686">P2Sample</row>
    <row label="r687" value="687">Inovaction Slovakia New</row>
    <row label="r688" value="688">Nikkei Research</row>
    <row label="r689" value="689">Quick Rewards 2</row>
    <row label="r690" value="690">PureProfile 4</row>
    <row label="r691" value="691">WebMD Version 2</row>
    <row label="r692" value="692">schnellResearch</row>
    <row label="r693" value="693">PMI-KR Supply Team only-For Certification-2016-5-9)</row>
    <row label="r694" value="694">W&amp;S Company -TH</row>
    <row label="r695" value="695">GMO-R-Supply Only (for Certification Study</row>
    <row label="r696" value="696">SOYI</row>
    <row label="r697" value="697">Track Opinion Research Private Limited</row>
    <row label="r698" value="698">Union panel</row>
    <row label="r699" value="699">Panel Sampling UAE</row>
    <row label="r700" value="700">Panel Sampling KSA</row>
    <row label="r701" value="701">Panel Sampling Qatar</row>
    <row label="r702" value="702">livra (ipsos)</row>
    <row label="r703" value="703">Prize-Prize-KR</row>
    <row label="r704" value="704">Asia Sample(Zhao Wenhai)</row>
    <row label="r705" value="705">(non Japan) Union Panel</row>
    <row label="r706" value="706">Quickrewards_REWARDTV PROJECTS ONLY</row>
    <row label="r707" value="707">e2eresearrch (for JDPower)</row>
    <row label="r708" value="708">SWG New</row>
    <row label="r709" value="709">Borderless - New</row>
    <row label="r710" value="710">Research for Good EU</row>
    <row label="r711" value="711">Elicit Research V.2</row>
    <row label="r712" value="712">Gallup</row>
    <row label="r713" value="713">MFour Mobile Research</row>
    <row label="r714" value="714">Prize-Prize JP</row>
    <row label="r715" value="715">PureProfile 5</row>
    <row label="r716" value="716">PureProfile-6</row>
    <row label="r717" value="717">Internet Research Bureau Pvt. Ltd. Version 2</row>
    <row label="r718" value="718">Data Diggers V2</row>
    <row label="r719" value="719">Student Edge_ver4</row>
    <row label="r720" value="720">GMI-CN</row>
    <row label="r721" value="721">Glocal Mind 3</row>
    <row label="r722" value="722">Ipsos V3</row>
    <row label="r723" value="723">TNS V3</row>
    <row label="r724" value="724">GFK Custom Research</row>
    <row label="r725" value="725">PIC-Taiwan</row>
    <row label="r726" value="726">Hiving 2</row>
    <row label="r727" value="727">Daedalus new</row>
    <row label="r728" value="728">Cido V2</row>
    <row label="r729" value="729">Charter Oak Field</row>
    <row label="r730" value="730">Dale! Network</row>
    <row label="r731" value="731">Consumer Link</row>
    <row label="r732" value="732">Opinionbridge TH</row>
    <row label="r733" value="733">Schmiedl</row>
    <row label="r734" value="734">GMI _Ireland</row>
    <row label="r735" value="735">Data Diggers</row>
    <row label="r736" value="736">Panel Sampling Iran</row>
    <row label="r737" value="737">DataSpring</row>
    <row label="r738" value="738">Pure Spectrum</row>
    <row label="r739" value="739">Dorinsight_new</row>
    <row label="r740" value="740">Markelytics v.1</row>
    <row label="r741" value="741">Apinio</row>
    <row label="r742" value="742">Netquest NEW</row>
    <row label="r743" value="743">CONG TY TNHH AP VIETNAM</row>
    <row label="r744" value="744">Prime Research</row>
    <row label="r745" value="745">iPanel(Israel)</row>
    <row label="r746" value="746">Sample bus New</row>
    <row label="r747" value="747">UMR Research</row>
    <row label="r748" value="748">MyPoints V2</row>
    <row label="r749" value="749">Opinionsbridge (JP)</row>
    <row label="r750" value="750">DataSpring New</row>
    <row label="r751" value="751">Mindtake - New</row>
    <row label="r752" value="752">JTN_Slovakia</row>
    <row label="r753" value="753">ARC_2</row>
    <row label="r754" value="754">Mindtake - Croatia</row>
    <row label="r755" value="755">Delete-GMI ORD-245772-V4H0 AU</row>
    <row label="r756" value="756">Mindtake Bulgaria</row>
    <row label="r757" value="757">Research Cart</row>
    <row label="r758" value="758">NextOn Services V2</row>
    <row label="r759" value="759">PureProfile-7-for NZ</row>
    <row label="r760" value="760">CM Research UK</row>
    <row label="r761" value="761">CM Research USA</row>
    <row label="r762" value="762">CM Research RU</row>
    <row label="r763" value="763">Intra Research (Baltic Panels) Lithuania</row>
    <row label="r764" value="764">Opinionsbridge (KR)</row>
    <row label="r765" value="765">Geopoll ( Mobile Accord)</row>
    <row label="r766" value="766">CG Selecties(Casa Grande)</row>
    <row label="r767" value="767">Geopoll ( Mobile Accord)_2</row>
    <row label="r768" value="768">Dialog offline</row>
    <row label="r769" value="769">Multidados_2</row>
    <row label="r770" value="770">Dialog new (CAPI)</row>
    <row label="r771" value="771">Panels4All_2</row>
    <row label="r772" value="772">Inovaction Croatia</row>
    <row label="r773" value="773">Borderless</row>
    <row label="r774" value="774">Culturati Research</row>
    <row label="r775" value="775">Bioinformatics</row>
    <row label="r776" value="776">Offerwise V.3</row>
    <row label="r777" value="777">OfferJuice</row>
    <row label="r778" value="778">A2Z Research</row>
    <row label="r779" value="779">M3 New</row>
    <row label="r780" value="780">Offerwise V.4</row>
    <row label="r781" value="781">Intra Research (Baltic Panels) Estonia</row>
    <row label="r782" value="782">Metrixlab</row>
    <row label="r783" value="783">JTN_2</row>
    <row label="r784" value="784">Acumen_ DO NOT USE</row>
    <row label="r785" value="785">Market Xcel Data Matrix</row>
    <row label="r786" value="786">MarketPlus</row>
    <row label="r787" value="787">Mindtake Bulgaria 2</row>
    <row label="r788" value="788">Czech National Panel Poland</row>
    <row label="r789" value="789">Market Cube USE as of 4.4.2017</row>
    <row label="r790" value="790">Lucid</row>
    <row label="r791" value="791">Research Now for ORD-270359 NO TERMS ACTIVE</row>
    <row label="r792" value="792">Populus</row>
    <row label="r793" value="793">SessionM</row>
    <row label="r794" value="794">AfriQuest</row>
    <row label="r795" value="795">PROLIFIC R (for SG office)</row>
    <row label="r796" value="796">Octopus</row>
    <row label="r797" value="797">Pointlogic</row>
    <row label="r798" value="798">Made in Surveys</row>
    <row label="r799" value="799">Prodege-1</row>
    <row label="r800" value="800">ThinkField Westsense</row>
    <row label="r801" value="801">ThinkField Researchpanel</row>
    <row label="r802" value="802">Market Cube France</row>
    <row label="r803" value="803">test roland</row>
    <row label="r804" value="804">3GEM Research &amp; Insights</row>
    <row label="r805" value="805">Asiamonitor</row>
    <row label="r806" value="806">Quest Global Research Group Inc</row>
    <row label="r807" value="807">Hankook (KR)</row>
    <row label="r808" value="808">Intersight 3</row>
    <row label="r809" value="809">intersight 4</row>
    <row label="r810" value="810">Culturati Research V2</row>
    <row label="r811" value="811">temp ORD-278013</row>
    <row label="r812" value="812">temp 2 ORD-278013</row>
    <row label="r813" value="813">Empathy Research/Pigsback Panel_3</row>
    <row label="r814" value="814">Cyber Data Circulation</row>
    <row label="r815" value="815">Medixline</row>
    <row label="r816" value="816">Interviewing Service of America</row>
    <row label="r817" value="817">Cyber Age Research</row>
    <row label="r818" value="818">Gallup KR</row>
    <row label="r819" value="819">Philomath Research Private Limited</row>
    <row label="r820" value="820">Research Illuminous</row>
    <row label="r821" value="821">Red Planet</row>
    <row label="r822" value="822">Go Web Survey</row>
    <row label="r823" value="823">Precise Research</row>
    <row label="r824" value="824">Global Opine</row>
    <row label="r825" value="825">Innovate V3</row>
    <row label="r826" value="826">Decision Lab</row>
    <row label="r827" value="827">Daedalus new with IPs</row>
    <row label="r828" value="828">NewVista</row>
    <row label="r829" value="829">Azure Knowledge</row>
    <row label="r830" value="830">Feedback Me new</row>
    <row label="r831" value="831">PureSpectrum</row>
    <row label="r832" value="832">Offerwise V1</row>
    <row label="r833" value="833">GFK Research V1</row>
    <row label="r834" value="834">The Digital Edge (TDE)</row>
    <row label="r835" value="835">Borderless Access NZ</row>
    <row label="r836" value="836">Coleman</row>
    <row label="r837" value="837">Dalia</row>
    <row label="r838" value="838">Panelbase 2</row>
    <row label="r839" value="839">Paradigm New</row>
    <row label="r840" value="840">Prodege New</row>
    <row label="r841" value="841">Datacentrum</row>
    <row label="r842" value="842">Crosstab (notch link)</row>
    <row label="r843" value="843">Wise Sample V3</row>
    <row label="r844" value="844">Research Now (NEW - SSI-RN NA)</row>
    <row label="r845" value="845">Research Now (NEW - SSI-RN-HC) (e-rewardsmedical.com end links)</row>
    <row label="r846" value="846">Research Now (NEW - SSI-RN EU)</row>
    <row label="r847" value="847">Research Now (NEW SSI-RN APC)</row>
    <row label="r848" value="848">Culturati V3</row>
    <row label="r849" value="849">Schlesinger Associates V2</row>
    <row label="r850" value="850">QQ Survey New</row>
    <row label="r851" value="851">Gillian Kenney Associates</row>
    <row label="r852" value="852">Research Now (NEW - SSI-RN-HC) (endlinks.researchnow.com links)</row>
    <row label="r853" value="853">Research Now Surveymyopinion.com</row>
    <row label="r854" value="854">RN OT</row>
    <row label="r855" value="855">SHC Universal</row>
    <row label="r856" value="856">Datacollect New</row>
    <row label="r857" value="857">Culturati V4</row>
    <row label="r858" value="858">Opinions/SpongeIT</row>
    <row label="r859" value="859">HPOL</row>
    <row label="r860" value="860">Focus Bari (Client)</row>
    <row label="r861" value="861">RN for ORD 317754 only</row>
    <row label="r862" value="862">Market Cube as of March 21 2018</row>
    <row label="r863" value="863">Borderless-temp for ORD-320582-Y7R0</row>
    <row label="r864" value="864">RN for ORD 323307 only</row>
    <row label="r865" value="865">TEG Rewards</row>
    <row label="r866" value="866">Plamed Pass Thru</row>
    <row label="r867" value="867">OP4G V1</row>
    <row label="r868" value="868">HPOL V1</row>
    <row label="r869" value="869">Wise Sample V3</row>
    <row label="r870" value="870">Toluna V3</row>
    <row label="r871" value="871">IFF Pass Through</row>
    <row label="r872" value="872">EMI V1</row>
    <row label="r873" value="873">iResearch V2</row>
    <row label="r874" value="874">NextOn Services V3</row>
    <row label="r875" value="875">Peanut Labs V3</row>
    <row label="r876" value="876">Think Now V2</row>
    <row label="r877" value="877">The Digital Edge (TDE)_2</row>
    <row label="r878" value="878">Conclave Research V2</row>
    <row label="r879" value="879">Opinion Route V2</row>
    <row label="r880" value="880">Paradigm New 1</row>
    <row label="r881" value="881">42 MR</row>
    <row label="r882" value="882">Purespectrum</row>
    <row label="r883" value="883">Wise Sample V4</row>
    <row label="r1002" value="1002">iPanel</row>
  </radio>

  <suspend/>

  <text 
   label="xpanelPartner2"
   cond="0"
   fwidth="2048"
   size="40"
   translateable="0"
   where="execute,survey,report">
    <title>xpanelPartner2</title>
    <row label="r1"/>
  </text>

  <suspend/>

  <block label="block_5" builder:title="5 variable">
    <exec>
############## dSampleFlag ##############

if FLAG == "" or FLAG == "0" or FLAG not in ["0","1","2"]: dSampleFlag.val = 0
if FLAG == "1": dSampleFlag.val = 1
if FLAG == "2": dSampleFlag.val = 2


############## dPanel ##############

Enrollment = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,64,65,66]
Invitation = [50,51,52,53,54,55,56,57,58,59,60,61,62,63,67,69,73,74,731]
Intercept = [68]
Panel = [70,71,72,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89]
Other = [90,91,92,93,94,95,96,97,98,99]

if panelSource.any:
	rowLab = panelSource.rows[panelSource.val].label.split('r')[1] 

	if int(rowLab) in Enrollment: dPanel.val = dPanel.r1.index		# Open enrollment
	if int(rowLab) in Invitation: dPanel.val = dPanel.r2.index		# Invitation Only
	if int(rowLab) in Intercept: dPanel.val = dPanel.r3.index		# Intercept panel
	if int(rowLab) in Panel: dPanel.val = dPanel.r4.index			# Panel Partner
	if int(rowLab) in Other: dPanel.val = dPanel.r5.index			# Other
    </exec>

    <suspend/>

    <radio 
    label="dSampleFlag"
    cond="0"
    randomize="0"
    translateable="0"
    where="execute,survey,report,notdp">
      <title>Sample Flag</title>
      <comment><i>Please select one only.</i></comment>
      <row label="r0" value="0">OFF or Not required</row>
      <row label="r1" value="1">Nat Rep</row>
      <row label="r2" value="2">Targeting</row>
    </radio>

    <radio 
    label="dPanel"
    cond="0"
    randomize="0"
    translateable="0"
    where="execute,survey,report,notdp">
      <title>Panel</title>
      <comment><i>Please select one only.</i></comment>
      <row label="r1">Open enrollment</row>
      <row label="r2">Invitation Only</row>
      <row label="r3">Intercept panel</row>
      <row label="r4">Panel Partner</row>
      <row label="r5">Other</row>
    </radio>

    <suspend/>
  </block>

  <suspend/>

  <exec>
##########################################################################
# if "w" variable removed from Live links, then update wave punch manually 
##########################################################################

Wave.val = Wave.r1.index

if w and w.isdigit():
	Wave.val = int(w)-1
  </exec>

  <suspend/>

  <radio 
   label="Wave"
   cond="tplShow()"
   optional="1"
   randomize="0"
   translateable="0"
   where="execute,survey,report">
    <title>Wave variable</title>
    <comment>Hide before launch</comment>
    <row label="r1" value="1">Wave 1</row>
    <row label="r2" value="2">Wave 2</row>
    <row label="r3" value="3">Wave 3</row>
    <row label="r4" value="4">Wave 4</row>
    <row label="r5" value="5">Wave 5</row>
    <row label="r6" value="6">Wave 6</row>
    <row label="r7" value="7">Wave 7</row>
    <row label="r8" value="8">Wave 8</row>
    <row label="r9" value="9">Wave 9</row>
    <row label="r10" value="10">Wave 10</row>
    <row label="r11" value="11">Wave 11</row>
    <row label="r12" value="12">Wave 12</row>
    <row label="r13" value="13">Wave 13</row>
    <row label="r14" value="14">Wave 14</row>
    <row label="r15" value="15">Wave 15</row>
    <row label="r16" value="16">Wave 16</row>
    <row label="r17" value="17">Wave 17</row>
    <row label="r18" value="18">Wave 18</row>
    <row label="r19" value="19">Wave 19</row>
    <row label="r20" value="20">Wave 20</row>
    <row label="r21" value="21">Wave 21</row>
    <row label="r22" value="22">Wave 22</row>
    <row label="r23" value="23">Wave 23</row>
    <row label="r24" value="24">Wave 24</row>
    <row label="r25" value="25">Wave 25</row>
    <row label="r26" value="26">Wave 26</row>
    <row label="r27" value="27">Wave 27</row>
    <row label="r28" value="28">Wave 28</row>
    <row label="r29" value="29">Wave 29</row>
    <row label="r30" value="30">Wave 30</row>
    <row label="r31" value="31">Wave 31</row>
    <row label="r32" value="32">Wave 32</row>
    <row label="r33" value="33">Wave 33</row>
    <row label="r34" value="34">Wave 34</row>
    <row label="r35" value="35">Wave 35</row>
    <row label="r36" value="36">Wave 36</row>
    <row label="r37" value="37">Wave 37</row>
    <row label="r38" value="38">Wave 38</row>
    <row label="r39" value="39">Wave 39</row>
    <row label="r40" value="40">Wave 40</row>
    <row label="r41" value="41">Wave 41</row>
    <row label="r42" value="42">Wave 42</row>
    <row label="r43" value="43">Wave 43</row>
    <row label="r44" value="44">Wave 44</row>
    <row label="r45" value="45">Wave 45</row>
    <row label="r46" value="46">Wave 46</row>
    <row label="r47" value="47">Wave 47</row>
    <row label="r48" value="48">Wave 48</row>
    <row label="r49" value="49">Wave 49</row>
    <row label="r50" value="50">Wave 50</row>
  </radio>

  <suspend/>

  <exec>
############################################
# Update punch and row text for Live Changes
############################################

dTrack.r0.val = 1
# dTrack.r1.val = 1
# dTrack.r2.val = 1
# dTrack.r3.val = 1
# dTrack.r4.val = 1
# dTrack.r5.val = 1
# dTrack.r6.val = 1
# dTrack.r7.val = 1
# dTrack.r8.val = 1
# dTrack.r9.val = 1
# dTrack.r10.val = 1
  </exec>

  <suspend/>

  <checkbox 
   label="dTrack"
   cond="tplShow()"
   randomize="0"
   translateable="0"
   where="execute,survey,report">
    <title>dTrack variable</title>
    <comment>Hide before launch</comment>
    <row label="r0">No Changes</row>
    <row label="r1">Change 1</row>
    <row label="r2">Change 2</row>
    <row label="r3">Change 3</row>
    <row label="r4">Change 4</row>
    <row label="r5">Change 5</row>
    <row label="r6">Change 6</row>
    <row label="r7">Change 7</row>
    <row label="r8">Change 8</row>
    <row label="r9">Change 9</row>
    <row label="r10">Change 10</row>
  </checkbox>

  <suspend/>
</block>

<quota label="Standard_Info" overquota="noqual" sheet="Standard_Info"/>

<block label="brnjumpto" cond="gv.survey.root.state.testing and jumpto" builder:title="JumpTo - please remove this block when go living">
  <exec>
try: rnjumpto.val = rnjumpto.attr(jumpto).index
except: pass
  </exec>

  <select 
   label="rnjumpto"
   cond="jumpto =='all' or rnjumpto.ival &gt; 0"
   optional="1"
   translateable="0"
   where="survey,notdp">
    <title>Please select a question to jump to.</title>
    <choice label="skip">Skip</choice>
    <style name="question.after"><![CDATA[
<style>#question_rnjumpto{display:none};</style>
<script>
$ (document).ready(function(){
  if($ ('.question').length == 1){
    var newSelect = $ (".answers select").clone();
    newSelect.attr("name","jumpto0");
    newSelect.attr("id", "jumpto0");
    newSelect.find("option").attr("selected",false).first().remove();
    newSelect.find("option").first().text("Jump to");
    sessionStorage.jumptoSelect = newSelect[0].outerHTML;
    $ ("#btn_continue").click();
  }
})
</script>
]]></style>
  </select>

  <suspend/>

  <exec cond="rnjumpto.ival&gt;0">
goto(allQuestions[rnjumpto.choices[rnjumpto.ival].label])
  </exec>
</block>

<suspend/>

<block label="block_FW" cond="0" builder:title="Fixed-Width of OE variables to either 16 (Tracker) or 1024 (Adhoc)">
  <note>########### Fixed-Width of OE variables -- Update the row label of "ProType" variable to either 'Tracker' (fixed-width 16) or 'Adhoc' (fixed-width 1024) ###########</note>
  <radio 
   label="ProType"
   cond="0"
   optional="1"
   randomize="0"
   translateable="0"
   where="execute,survey,report,notdp">
    <title>Project Type</title>
    <comment>Update label to either 'Tracker' or 'Adhoc'</comment>
    <row label="Adhoc">Tracker / Adhoc</row>
  </radio>
</block>

<exec>
print "CHECK THIS IS CORRECT : Survey type = " + ProType.label
</exec>

<suspend/>

<note>########### Validate for "value" defined in Rows/Cols in Checkbox Question -- Update the row label to "ON" for validate and "OFF" to avoid this validate ###########</note>
<radio 
  label="CheckboxValueCheck"
  cond="0"
  optional="1"
  randomize="0"
  translateable="0"
  where="none">
  <title>Checkbox Value Check -- Enable or Disable this check from here</title>
  <row label="ON">ON / OFF</row>
</radio>

<suspend/>

<note>=================================[ Audio / Video Screener Questions ]=================================</note>
<suspend/>

<block label="block_AudioScreener" cond="0" builder:title="Audio Screener">
  <radio 
   label="AudioScreener_Path"
   randomize="0"
   sst="0"
   translateable="0"
   where="execute,survey,notdp">
    <title>Audio Screener Path</title>
    <exec>
arr = [0,1,2]

random.shuffle(arr)

AudioScreener_Path.val = arr[0]
    </exec>

    <row label="r1">/survey/selfserve/53b/161290/Screener_Audio_lu.mp3</row>
    <row label="r2">/survey/selfserve/53b/161290/Screener_Audio_mark.mp3</row>
    <row label="r3">/survey/selfserve/53b/161290/Screener_Audio_tom.mp3</row>
  </radio>

  <suspend/>

  <checkbox 
   label="AudioScreener_Player"
   audio:enable_autoplay="1"
   audio:enable_pause="0"
   audio:enable_replay="1"
   audio:file="${AudioScreener_Path.selected.text}"
   audio:must_listen="0"
   randomize="0"
   sst="0"
   uses="audio.3"
   where="survey,notdp">
    <title>Please click on the "PLAY" button when you are ready.</title>
  </checkbox>

  <radio 
   label="AudioScreener"
   randomize="0"
   sst="0"
   where="survey,notdp">
    <title>Please identify the animal you just heard.</title>
    <comment>${res.SCInst}</comment>
    <row label="r1">Dog</row>
    <row label="r2">Cat</row>
    <row label="r3">Elephant</row>
    <row label="r4">Frog</row>
    <row label="r5">Ape</row>
    <row label="r6">Horse</row>
    <row label="r7">Bird</row>
    <row label="r8" randomize="0">I could not hear the animal</row>
  </radio>

  <suspend/>

  <term label="Term_Audio_Screener" cond="AudioScreener_Path.val != AudioScreener.val" sst="0">Term: Audio Screener</term>

  <suspend/>
</block>

<block label="block_VideoScreener" cond="0" builder:title="Video Screener">
  <radio 
   label="VideoScreener_Path"
   randomize="0"
   sst="0"
   translateable="0"
   where="execute,survey,notdp">
    <title>Video Screener Path</title>
    <exec>
arr = [0,1,2,3,4]

random.shuffle(arr)

VideoScreener_Path.val = arr[0]
    </exec>

    <row label="r1" alt="Screener_Video_lu">6038754835001</row>
    <row label="r2" alt="Screener_Video_mark">6038754833001</row>
    <row label="r3" alt="Screener_Video_tom">6038754677001</row>
    <row label="r4" alt="Screener_Video_tav">6038753728001</row>
    <row label="r5" alt="Screener_Video_steve">6038753727001</row>
  </radio>

  <suspend/>

  <text 
   label="VideoScreener_Player"
   optional="0"
   randomize="0"
   size="25"
   sst="0"
   uses="videoplayer.1"
   videoplayer:account_id="2280166212001"
   videoplayer:autostart="1"
   videoplayer:disable_continue="0"
   videoplayer:height="300"
   videoplayer:hide_volume="1"
   videoplayer:player_id="WxkzMz4Kr"
   videoplayer:replay_enable="1"
   videoplayer:video_id="${VideoScreener_Path.selected.text}"
   videoplayer:width="420"
   where="survey,notdp">
    <title>Please click on the "PLAY" button when you are ready.</title>
  </text>

  <radio 
   label="VideoScreener"
   randomize="0"
   sst="0"
   where="survey,notdp">
    <title>What animal can you see in the video above?</title>
    <comment>${res.SCInst}</comment>
    <row label="r1">Dog</row>
    <row label="r2">Cat</row>
    <row label="r3">Elephant</row>
    <row label="r4">Frog</row>
    <row label="r5">Ape</row>
    <row label="r6">Horse</row>
    <row label="r7">Bird</row>
    <row label="r8" randomize="0">I could not see the animal</row>
  </radio>

  <suspend/>

  <term label="Term_Video_Screener" cond="VideoScreener_Path.val != VideoScreener.val" sst="0">Term: Video Screener</term>

  <suspend/>
</block>

<note>=================================[ Recaptcha Questions ]=================================</note>
<suspend/>

<block label="block_Recaptcha" cond="0" builder:title="Recaptcha">
  <logic label="recaptcha" recaptcha:secret="6Lfxy3cgAAAAACEoBkEBzvhWf-2cPkOMk2oXHkJf" recaptcha:sitekey="6Lfxy3cgAAAAAFqXtKpaInjWUJY1SN1OzZZlNvMl" uses="recaptcha.1"/>
  <suspend/>

  <term label="termrechapcha" cond="not recaptcha.human" sst="0">ReCaptcha Fail</term>
</block>

<suspend/>

<exec when="init">
#def quota_hook(sheet, table, cells):
#  if 'priorQSheet' in sheet:
#    Qid = sheet[11:]; 
#    PQid = Qid+'Prior'; 
#    MPre = '/'+Qid+'Cell';  
#    cellsOrdered = []; 
#    QInfo=[]
#    for x in allQuestions[PQid].rows:
#      if x:
#        QInfo.append({'labelref':x.label, 'textref':x.text, 'prior':x.val, 'marker':MPre+'_'+x.label[1:]+'/'})
#    QInfo = sorted(QInfo, key = lambda i: i['prior'])
#    markerPriorities = []
#    lastprior = ""
#    for x in QInfo:
#      if lastprior=='' or not lastprior==x['prior']:
#        markerPriorities.append([])
#        lastprior=x['prior']
#      markerPriorities[len(markerPriorities)-1].append(x['marker'])
#    for eachPriority in markerPriorities:
#      for eachCell in cells:
#        for inprior in eachPriority:
#          if inprior in eachCell[2]+'/':
#            cellsOrdered.append(eachCell)
#    return cellsOrdered
#  else:
#    return cells
#  
#def punchMarker(selectid):
#  refid = selectid[:-6]
#  sheetid = 'priorQSheet'+refid
#  mylist= allQuestions[selectid].rows+allQuestions[selectid].choices
#  for x in mylist:
#    inmark = '/'+refid+'Cell_'+x.label[1:]+'/'
#    for eachmarker in p.markers:
#      if inmark in eachmarker+'/':
#        if allQuestions[selectid].o.xmlTagName in ['radio','select']:
#          allQuestions[selectid].val = x.index
#        else:
#          x.val=1
</exec>

<note>=================================[ Audio / Video Screener Questions ]=================================</note>
<suspend/>

<note>=================================[ Start = Questionnaire ]=================================</note>
<html label="INTRO3" where="survey">START Part 3</html>

<suspend/>

<exec when="init">
quota_hook_config = {
	"Part3" : {
		"method" : "Exclusive",
		"limit"  : 5,
		"data": {
			"r1": ["r6","r7","r8"],
			"r2": [],
			"r3": [],
			"r4": [],
			"r5": [],
			"r6": [],
			"r7": [],
			"r8": [],
			"r9": []
		}	
	}
}


def quota_hook(sheet, table, cells):
	if sheet in quota_hook_config.keys():
	
		configuration = quota_hook_config[sheet]
		method = configuration["method"]
		limit = configuration["limit"]
		data = configuration["data"]
		
		if method == "Exclusive":
			
			concept = []
			exclude = []
			
			for eachCell in cells:
				key = eachCell[2].split("_")[1]
				exclusion = data[key]
				if len(concept) lt limit and key not in exclude:
					concept.append(eachCell)
					exclude.extend(exclusion)
			
			return concept
	else:
		return cells
</exec>

<checkbox 
  label="P3"
  atleast="1">
  <title>Picked preferred company:</title>
  <comment>Please select all that apply</comment>
  <row label="r1">Product 1</row>
  <row label="r2">Product 2</row>
  <row label="r3">Product 3</row>
  <row label="r4">Product 4</row>
  <row label="r5">Product 5</row>
  <row label="r6">Product 6</row>
  <row label="r7">Product 7</row>
  <row label="r8">Product 8</row>
  <row label="r9">Product 9</row>
</checkbox>

<suspend/>

<quota label="Part3_Quota" overquota="noqual" sheet="Part3"/>

<exec>
P3.r1.val = False
print p.markers
</exec>

<html label="INTRO" where="survey">START</html>

<quota label="LF_Part2_Quota" overquota="noqual" sheet="LFPart2"/>

<exec>
for eachRow in xP2.rows:
    if hasMarker('/LFPart2/xP2_' + eachRow.label):
        xP2.val = eachRow.index
</exec>

<radio 
  label="xP2"
  where="execute,survey,report">
  <title>Picked 1 through least fill and use these as the priority Least Fill Quota</title>
  <comment>Please select one</comment>
  <row label="r1">BANK 3,BANK 2,BANK 1,BANK 5,BANK 4</row>
  <row label="r2">BANK 2,BANK 1,BANK 4,BANK 3,BANK 5</row>
  <row label="r3">BANK 1,BANK 5,BANK 2,BANK 4,BANK 3</row>
</radio>

<suspend/>

<exec>
xP2Selection = xP2.selected.text
xP2Array = xP2Selection.split(',')

#setting order
Order = [int(eachItem.split(' ')[1]) - 1 for eachItem in xP2Array]
xP2Bank.rows.order = Order
</exec>

<exec when="init">
#def quota_hook(sheet, table, cells):
#    if sheet == 'Part2':
#        cellsOrder = []
#        xP2Selection = xP2.selected.text
#        limit = 3
#        count = 0
#        xP2Array = xP2Selection.split(',')
#        marker = ['/Part2/P2_%s' % eachItem.split(' ')[1] for eachItem in xP2Array]
#        xP2Order = [ [marker[0]], [marker[1]] , [marker[2]] , [marker[3]] , [marker[4]]]
#
#        for eachRow in xP2Order:
#            for eachCell in cells:
#                if eachCell[2] in eachRow and count lt limit:
#                    cellsOrder.append(eachCell)
#                    count += 1
#        return cellsOrder
#    else:
#        return cells
</exec>

<quota label="Part2_Quota" overquota="noqual" sheet="Part2"/>

<suspend/>

<exec>
print p.markers
for x in xP2Bank.rows:
    x.val = 0
    if hasMarker('/Part2/P2_%s' % x.label[1:]):
        x.val = 1
</exec>

<checkbox 
  label="xP2Bank"
  shuffle="rows"
  where="execute,survey,report">
  <title>Bank Selection</title>
  <comment>Please select all that apply</comment>
  <row label="r1">Bank 1</row>
  <row label="r2">Bank 2</row>
  <row label="r3">Bank 3</row>
  <row label="r4">Bank 4</row>
  <row label="r5">Bank 5</row>
</checkbox>

<text 
  label="xP2BankOrder"
  size="40"
  where="execute,survey,report">
  <title>Store First, Second and Third bank according to ORDER in xP2. (Least Fill basis)</title>
  <exec>
flagSelection = []
for x in xP2BankOrder.rows:
	for y in xP2Bank.rows.order:
		if y and y.label not in flagSelection:	
			flagSelection.append(y.label)
			x.val = y.text
			break
  </exec>

  <row label="r1">1</row>
  <row label="r2">2</row>
  <row label="r3">3</row>
</text>

<suspend/>

<checkbox 
  label="P1"
  atleast="1">
  <title>Picked preferred company:</title>
  <comment>Please select all that apply</comment>
  <row label="r1">Chevron</row>
  <row label="r2">ExxonMobil</row>
  <row label="r3">BP</row>
  <row label="r4">Shell</row>
  <row label="r5">Total</row>
  <row label="r6">PTT Exploration and Production (PTTEP)</row>
  <row label="r7">Mubadala Petroleum</row>
  <row label="r8">Bangchak Corporation</row>
  <row label="r9">Gulf Energy</row>
</checkbox>

<suspend/>

<exec when="init">
#def quota_hook(sheet, table, cells):
#    if sheet == 'Part1':
#        priorityBrands = ['r1','r5','r6','r7','r8','r9']
#        limit = 4
#        count = 0
#        top6Markers = ['/Part1/P1_%s' % x.label[1:] for x in P1.rows if x and x.label in priorityBrands] 
#        notTop6 = ['/Part1/P1_%s' % x.label[1:] for x in P1.rows if x and x.label not in priorityBrands] 
#
#        priorityLevel = [top6Markers,notTop6]
#        cellsOrder = []
#        for eachRow in priorityLevel:
#            for eachCell in cells:
#                if len(top6Markers) == 6 :
#                    if eachCell[2] in eachRow and eachCell[2] in top6Markers:
#                        cellsOrder.append(eachCell)
#                else:
#                    if count lt limit:
#                        if eachCell[2] in eachRow:
#                            cellsOrder.append(eachCell)
#                            count += 1
#        return cellsOrder
#    else:
#        return cells
</exec>

<quota label="Part1_Quota" cond="0" overquota="noqual" sheet="Part1"/>

<suspend/>

<exec>
print p.markers
</exec>

<radio 
  label="Q1">
  <title>Please rate the brands based on satisfaction.</title>
  <col label="c1">Very Unsatisfied</col>
  <col label="c2">Unsatisfied</col>
  <col label="c3">Neither</col>
  <col label="c4">Satisfied</col>
  <col label="c5">Very Satisfied</col>
  <row label="r1">Brand A</row>
  <row label="r2">Brand B</row>
  <row label="r3">Brand C</row>
  <row label="r4">Brand D</row>
</radio>

<suspend/>

<exec when="init">
#def quota_hook(sheet, table, cells):
# if sheet == 'Brand Selection':
#   cellsOrdered = []
#   C1 = ['/Brand Selection/Brand_' + eachRow.label for eachRow in Q1.rows if eachRow.c1]
#   C2 = ['/Brand Selection/Brand_' + eachRow.label for eachRow in Q1.rows if eachRow.c2]
#   C3 = ['/Brand Selection/Brand_' + eachRow.label for eachRow in Q1.rows if eachRow.c3]
#   C4 = ['/Brand Selection/Brand_' + eachRow.label for eachRow in Q1.rows if eachRow.c4]
#   C5 = ['/Brand Selection/Brand_' + eachRow.label for eachRow in Q1.rows if eachRow.c5]
#   markerPriorities = [C5,C4,C3,C2,C1]
#   for eachPriority in markerPriorities:
#     for eachCell in cells:
#       if eachCell[2] in eachPriority:
#         cellsOrdered.append(eachCell)
#   return cellsOrdered
# else:
#   return cells
</exec>

<suspend/>

<quota label="Brand_Selection_Quota" overquota="noqual" sheet="Brand Selection"/>

<suspend/>

<exec>
#print quota_hook.keys()
print p.markers
for eachRow in Brands_Selected.rows:
    if hasMarker('/Brand Selection/Brand_' + eachRow.label):
        eachRow.val = 1
</exec>

<checkbox 
  label="Brands_Selected"
  atleast="1">
  <title>Test</title>
  <row label="r1">Brand A</row>
  <row label="r2">Brand B</row>
  <row label="r3">Brand C</row>
  <row label="r4">Brand D</row>
</checkbox>

<suspend/>

<checkbox 
  label="QCY1"
  atleast="1">
  <title>TEST</title>
  <row label="r1">TOP 6 -</row>
  <row label="r5">TOP 6 -</row>
  <row label="r20">TOP 6 -</row>
  <row label="r21">TOP 6 -</row>
  <row label="r86">TOP 6 -</row>
  <row label="r87">TOP 6 -</row>
  <row label="r2">not</row>
  <row label="r3">not</row>
  <row label="r4">not</row>
  <row label="r6">not</row>
  <row label="r7">not</row>
  <row label="r8">not</row>
  <row label="r9">not</row>
</checkbox>

<suspend/>

<exec>
for x in QCY1.rows:
    if x and x.label in ['r1','r5','r20','r21','r86','r87']:
        QCY1Prior.attr(x.label).val = 1
    elif x :
        QCY1Prior.attr(x.label).val = 9
</exec>

<number 
  label="QCY1Prior"
  size="3"
  where="execute,survey,report">
  <title>TEST</title>
  <row label="r1">TOP 6 -</row>
  <row label="r5">TOP 6 -</row>
  <row label="r20">TOP 6 -</row>
  <row label="r21">TOP 6 -</row>
  <row label="r86">TOP 6 -</row>
  <row label="r87">TOP 6 -</row>
  <row label="r2">not</row>
  <row label="r3">not</row>
  <row label="r4">not</row>
  <row label="r6">not</row>
  <row label="r7">not</row>
  <row label="r8">not</row>
  <row label="r9">not</row>
</number>

<suspend/>

<quota label="quotaQCY" overquota="noqual" sheet="priorQSheetQCY1"/>

<suspend/>

<exec cond="1">
#print p.markers
#punchMarker("QCY1Select")
</exec>

<checkbox 
  label="QCY1Select"
  optional="1"
  where="execute,survey,report">
  <title>TEST</title>
  <row label="r1">TOP 6 -</row>
  <row label="r5">TOP 6 -</row>
  <row label="r20">TOP 6 -</row>
  <row label="r21">TOP 6 -</row>
  <row label="r86">TOP 6 -</row>
  <row label="r87">TOP 6 -</row>
  <row label="r2">not</row>
  <row label="r3">not</row>
  <row label="r4">not</row>
  <row label="r6">not</row>
  <row label="r7">not</row>
  <row label="r8">not</row>
  <row label="r9">not</row>
</checkbox>

<suspend/>

<quota label="testQuota" overquota="noqual" sheet="Sheet1"/>

<exec>
celltest = {
	0: 12,
	1: 'key',
	2: ['b1','b2','b3','b4']
}

#print celltest[2]

#if celltest[2] in ('b1'):
#    print 'test-True1'
#
#if celltest[1] in ('key'):
#    print 'test-True2'
#    
#for eachCell in celltest:
#    print eachCell[0]
#    if eachCell[2] in ('b2'):
#        print celltest
</exec>

<exec when="init">
#C1 = '/Sheet1/BrandA'
#C2 = '/Sheet1/BrandB'
#def quota_hook(sheet, table, cells):
#    if sheet == 'Sheet1':
#        assignedCell = False
#        for eachCell in cells:
#            #if eachCell[2] in (C1,C2):
#            #    assignedCell = True
#            if eachCell[0] in (C1,C2):
#                if assignedCell:
#                    cells.remove(eachCell)
#                    break
#                else:
#                    assignedCell = True
#    return cells
</exec>

<exec>
print p.markers
#print quota_hook('Sheet1')
</exec>

<text 
  label="Q1_2"
  cond="1">
  <title>Dummy Question</title>
  <row label="r1">Dummy 1</row>
  <row label="r2">Dummy 2</row>
</text>

<suspend/>

<radio 
  label="Q1_3"
  atm1d:showInput="0"
  atm1d:viewMode="tiled"
  uses="atm1d.9">
  <title>Are you...?</title>
  <comment>${res.SCInst}</comment>
  <row label="r1" alt="Male"><img src="[rel maleDefault_v2.png]" class="survey_image survey-image-original" title="Male" /></row>
  <row label="r2" alt="Female"><img src="[rel femaleDefault_v2.png]" class="survey_image survey-image-original" title="Female" /></row>
</radio>

<suspend/>

<term label="TermQ1_3" cond="Q1_3.r2">Term : Q1_3</term>

<radio 
  label="Q2_2"
  atm1d:large_buttonAlign="center"
  atm1d:large_maxWidth="250px"
  atm1d:small_buttonAlign="center"
  atm1d:viewMode="tiled"
  randomize="0"
  uses="atm1d.9">
  <title>What type of vehicle do you own?</title>
  <comment>${res.SCInst}</comment>
  <style name="page.head"><![CDATA[
<style>
.sq-atm1d-button { width:200px; }
</style>
]]></style>
  <row label="r1">Microcar</row>
  <row label="r2">SUV</row>
  <row label="r3">Hatchback</row>
  <row label="r4">Sedan</row>
  <row label="r5">Sport</row>
  <row label="r6">Luxury</row>
</radio>

<radio 
  label="Q2_3"
  atm1d:large_buttonAlign="center"
  atm1d:large_maxWidth="450px"
  atm1d:small_buttonAlign="center"
  atm1d:viewMode="tiled"
  randomize="0"
  uses="atm1d.9">
  <title>What type of vehicle do you own?</title>
  <comment>${res.SCInst}</comment>
  <style name="page.head"><![CDATA[
<style>
.sq-atm1d-button { width:250px; }
.sq-atm1d-td { vertical-align: bottom; }
</style>
]]></style>
  <row label="r1"><img src="/survey/selfserve/53b/161290/Microcar.png" width="200" /><br /><br />Microcar</row>
  <row label="r2"><img src="/survey/selfserve/53b/161290/SUV.png" width="200" /><br /><br />SUV</row>
  <row label="r3"><img src="/survey/selfserve/53b/161290/Hatchback.png" width="200" /><br /><br />Hatchback</row>
  <row label="r4"><img src="/survey/selfserve/53b/161290/Sedan.png" width="200" /><br /><br />Sedan</row>
  <row label="r5"><img src="/survey/selfserve/53b/161290/Sport.png" width="200" /><br /><br />Sport</row>
  <row label="r6"><img src="/survey/selfserve/53b/161290/Luxury.png" width="200" /><br /><br />Luxury</row>
</radio>

<suspend/>

<checkbox 
  label="Q3_2"
  atleast="1"
  atm1d:large_buttonAlign="center"
  atm1d:large_maxWidth="250px"
  atm1d:small_buttonAlign="center"
  atm1d:viewMode="tiled"
  randomize="0"
  uses="atm1d.9">
  <title>What of the following gadget(s) do you have?</title>
  <comment>${res.MRInst}</comment>
  <style name="page.head"><![CDATA[
<style>
.sq-atm1d-button { width:200px; }
</style>
]]></style>
  <row label="r1">Mobile</row>
  <row label="r2">Tablet</row>
  <row label="r3">Laptop</row>
  <row label="r4">Desktop</row>
  <row label="r5">Smart Watch</row>
  <row label="r6">Gaming device</row>
</checkbox>

<checkbox 
  label="Q3_3"
  atleast="1"
  atm1d:large_buttonAlign="center"
  atm1d:large_maxWidth="250px"
  atm1d:small_buttonAlign="center"
  atm1d:viewMode="tiled"
  randomize="0"
  uses="atm1d.9">
  <title>What of the following gadget(s) do you have?</title>
  <comment>${res.MRInst}</comment>
  <style name="page.head"><![CDATA[
<style>
.sq-atm1d-button { width:250px; }
.sq-atm1d-td { vertical-align: bottom; }
</style>
]]></style>
  <row label="r1"><img src="/survey/selfserve/53b/161290/Mobile.png" width="150" /><br />Mobile</row>
  <row label="r2"><img src="/survey/selfserve/53b/161290/Tablet.png" width="200" /><br />Tablet</row>
  <row label="r3"><img src="/survey/selfserve/53b/161290/Laptop.png" width="200" /><br />Laptop</row>
  <row label="r4"><img src="/survey/selfserve/53b/161290/Desktop.png" width="200" /><br />Desktop</row>
  <row label="r5"><img src="/survey/selfserve/53b/161290/SmartWatch.png" width="200" /><br />Smart Watch</row>
  <row label="r6"><img src="/survey/selfserve/53b/161290/GamingDevice.png" width="200" /><br />Gaming device</row>
</checkbox>

<suspend/>

<radio 
  label="Q4_2"
  uses="atmtable.6">
  <title>How satisfied are you with the performance of these cars?</title>
  <comment>${res.SCGInst}</comment>
  <col label="c1" atmtable:col_legend_text="Extremely satisfied">1</col>
  <col label="c2" atmtable:col_legend_text="Very satisfied">2</col>
  <col label="c3" atmtable:col_legend_text="Neutral">3</col>
  <col label="c4" atmtable:col_legend_text="Very dissatisfied">4</col>
  <col label="c5" atmtable:col_legend_text="Extremely dissatisfied">5</col>
  <row label="r1"><div style="text-align:center;"><img src="/survey/selfserve/53b/161290/Microcar_1.png" height="50" /><br />Microcar</div></row>
  <row label="r2"><div style="text-align:center;"><img src="/survey/selfserve/53b/161290/SUV_1.png" height="50" /><br />SUV</div></row>
  <row label="r3"><div style="text-align:center;"><img src="/survey/selfserve/53b/161290/Hatchback_1.png" height="50" /><br />Hatchback</div></row>
  <row label="r4"><div style="text-align:center;"><img src="/survey/selfserve/53b/161290/Sedan_1.png" height="50" /><br />Sedan</div></row>
  <row label="r5"><div style="text-align:center;"><img src="/survey/selfserve/53b/161290/Sport_1.png" height="50" /><br />Sport</div></row>
  <row label="r6"><div style="text-align:center;"><img src="/survey/selfserve/53b/161290/Luxury_1.png" height="50" /><br />Luxury</div></row>
</radio>

<suspend/>

<number 
  label="Q9_1"
  atmrating:OO_Text="No Answer"
  ignoreValues="99"
  optional="0"
  size="10"
  uses="atmrating.5"
  verify="range(0,10)">
  <title>Using a scale 0 - Not at all important to 10 - Very important, please rate the following aspects of our service in the restaurant.</title>
  <comment><i>Please click on the button to rate the following aspects.</i></comment>
  <row label="r1">Speed of Service</row>
  <row label="r2">Friendliness of Staff</row>
</number>

<suspend/>

<radio 
  label="Q9_2"
  fir="off"
  grouping="rows"
  uses="cardrating.1">
  <title>Please rate the following types of cars on the basis of their performance.</title>
  <comment><i>Please select a button for each car type where 1 - Extremely satisfied and 5 - Extremely dissatisfied.</i></comment>
  <col label="c1">Extremely satisfied<br />1</col>
  <col label="c2"><br />2</col>
  <col label="c3">Neutral<br />3</col>
  <col label="c4"><br />4</col>
  <col label="c5">Extremely dissatisfied<br />5</col>
  <row label="r1"><img src="/survey/selfserve/53b/161290/Microcar_1.png" width="100" /><br />Microcar</row>
  <row label="r2"><img src="/survey/selfserve/53b/161290/SUV_1.png" width="100" /><br />SUV</row>
  <row label="r3"><img src="/survey/selfserve/53b/161290/Hatchback_1.png" width="100" /><br />Hatchback</row>
  <row label="r4"><img src="/survey/selfserve/53b/161290/Sedan_1.png" width="100" /><br />Sedan</row>
  <row label="r5"><img src="/survey/selfserve/53b/161290/Sport_1.png" width="100" /><br />Sport</row>
  <row label="r6"><img src="/survey/selfserve/53b/161290/Luxury_1.png" width="100" /><br />Luxury</row>
</radio>

<suspend/>

<select 
  label="Q9_6"
  minRanks="4"
  optional="1"
  ranksort:bucketCSS="height:130px; border-radius: 20px;"
  ranksort:cardCSS="height:130px; border-radius: 20px;"
  ranksort:showBucketNumber="0"
  unique="none,cols"
  uses="ranksort.4">
  <title>Please provide rating for following types of gadgets on the basis of their accessibility of internet services.</title>
  <comment><i>Please drag a gadget on the left into the appropriate box on the right which indicates 1st most preferable, 2nd most preferable, 3rd most preferable and 4th most preferable reason choosing.</i></comment>
  <row label="r1"><div style="text-align:center;"><img src="/survey/selfserve/53b/161290/Mobile.png" width="60" /><br />Mobile</div></row>
  <row label="r2"><div style="text-align:center;"><img src="/survey/selfserve/53b/161290/Tablet.png" width="100" /><br />Tablet</div></row>
  <row label="r3"><div style="text-align:center;"><img src="/survey/selfserve/53b/161290/Laptop.png" width="100" /><br />Laptop</div></row>
  <row label="r4"><div style="text-align:center;"><img src="/survey/selfserve/53b/161290/Desktop.png" width="100" /><br />Desktop</div></row>
  <choice label="ch1">1</choice>
  <choice label="ch2">2</choice>
  <choice label="ch3">3</choice>
  <choice label="ch4">4</choice>
</select>

<suspend/>

<radio 
  label="Q5_1"
  cardsort:bucketCSS="width:15%; height:70px; text-align:center !important; overflow:hidden; padding:0 !important;"
  cardsort:cardMaxWidth="500px"
  cardsort:completionHTML=""
  cardsort:displayCounter="0"
  cardsort:displayNavigation="0"
  cardsort:displayProgress="1"
  uses="cardsort.6">
  <title>How satisfied are you with the performance of these cars?</title>
  <comment>${res.SCInst}</comment>
  <style cond="device.mobileDevice" name="page.head"><![CDATA[
<script>
jQuery(document).ready(function()
{
	jQuery('.sq-cardsort-bucket').click(function()
	{
		setTimeout(function() { jQuery(window).scrollTop(0); },500)
	});
});
</script>
]]></style>
  <style name="page.head"><![CDATA[
<script>
jQuery(document).ready(function()
{
	jQuery('#img_continue, #btn_continue').css('display','none');
	jQuery('.sq-cardsort-progress').css('display','none');
	
	jQuery('.sq-cardsort-buckets li.sq-cardsort-bucket').click(function()
	{
		setTimeout(function()
		{
			if (jQuery('.sq-cardsort-cards li').hasClass('sq-cardsort-state-selected'))
			{
				checkSelection()
			}
		},300);
	});
});

function checkSelection()
{
	var rowCounter = jQuery('.sq-cardsort-card').length; 
	
	if (jQuery('.sq-cardsort-progress').text() == '-/-')
	{
		jQuery('#img_continue, #btn_continue').fadeIn(500);
		
		jQuery('#img_continue, #btn_continue').click();
	}
}
</script>
]]></style>
  <row label="r1"><img src="/survey/selfserve/53b/161290/Microcar.png" width="200" /><br />Microcar</row>
  <row label="r2"><img src="/survey/selfserve/53b/161290/SUV.png" width="200" /><br />SUV</row>
  <row label="r3"><img src="/survey/selfserve/53b/161290/Hatchback.png" width="200" /><br />Hatchback</row>
  <row label="r4"><img src="/survey/selfserve/53b/161290/Sedan.png" width="200" /><br />Sedan</row>
  <row label="r5"><img src="/survey/selfserve/53b/161290/Sport.png" width="200" /><br />Sport</row>
  <row label="r6"><img src="/survey/selfserve/53b/161290/Luxury.png" width="200" /><br />Luxury</row>
  <col label="c1">Extremely satisfied</col>
  <col label="c2">Very satisfied</col>
  <col label="c3">Neutral</col>
  <col label="c4">Very dissatisfied</col>
  <col label="c5">Extremely dissatisfied</col>
</radio>

<suspend/>

<checkbox 
  label="Q5_2"
  atleast="1"
  cardsort:bucketCSS="width:15%; height:70px; text-align:center !important; overflow:hidden; padding:0 !important;"
  cardsort:cardMaxWidth="500px"
  cardsort:completionHTML=""
  cardsort:displayCounter="0"
  cardsort:displayNavigation="0"
  cardsort:displayProgress="1"
  uses="cardsort.6">
  <title>Please select the brands you have for these gadgets?</title>
  <comment>${res.MRInst}</comment>
  <style name="page.head"><![CDATA[
<script>
jQuery(document).ready(function()
{
	jQuery('#img_continue, #btn_continue').css('display','none');
	jQuery('.sq-cardsort-progress').css('display','none');
	
	jQuery('.sq-cardsort-buckets li.sq-cardsort-bucket').click(function()
	{
		setTimeout(function()
		{
			if (jQuery('.sq-cardsort-cards li').hasClass('sq-cardsort-state-selected'))
			{
				checkSelection()
			}
		},300);
	});
});

function checkSelection()
{
	var rowCounter = jQuery('.sq-cardsort-card').length; 
	
	if (jQuery('.sq-cardsort-progress').text() == rowCounter+"/"+rowCounter)
	{
		jQuery('.sq-cardsort-next').fadeOut(500);
		
		jQuery('#img_continue, #btn_continue').fadeIn(500);
	}
}
</script>
]]></style>
  <row label="r1"><img src="/survey/selfserve/53b/161290/Mobile.png" width="150" /><br />Mobile</row>
  <row label="r2"><img src="/survey/selfserve/53b/161290/Tablet.png" width="200" /><br />Tablet</row>
  <row label="r3"><img src="/survey/selfserve/53b/161290/Laptop.png" width="200" /><br />Laptop</row>
  <row label="r4"><img src="/survey/selfserve/53b/161290/Desktop.png" width="200" /><br />Desktop</row>
  <row label="r5"><img src="/survey/selfserve/53b/161290/SmartWatch.png" width="200" /><br />Smart Watch</row>
  <row label="r6"><img src="/survey/selfserve/53b/161290/GamingDevice.png" width="200" /><br />Gaming device</row>
  <col label="c1">Brand 1</col>
  <col label="c2">Brand 2</col>
  <col label="c3">Brand 3</col>
  <col label="c4">Brand 4</col>
  <col label="c5">Brand 5</col>
</checkbox>

<suspend/>

<note>=================================[ End = Questionnaire ]=================================</note>
<suspend/>

<exec when="started">
import datetime 

StartDateTime = datetime.datetime.today()

StartDateTime = StartDateTime.strftime('%d-%m-%Y %H:%M:%S')

Survey_Time.Start.val = StartDateTime
</exec>

<exec when="finished">
import datetime


EndDateTime = datetime.datetime.today()

EndDateTime = EndDateTime.strftime('%d-%m-%Y %H:%M:%S')

Survey_Time.End.val = EndDateTime


start = datetime.datetime.strptime(Survey_Time.Start.val, '%d-%m-%Y %H:%M:%S')
end = datetime.datetime.strptime(Survey_Time.End.val, '%d-%m-%Y %H:%M:%S')

diff = (end - start)


Survey_Time.Total.val = str(diff)

Survey_Time.Total_Seconds.val = diff.total_seconds()

Survey_Time.Total_Minutes.val = round((diff.total_seconds() / 60.0),2)
</exec>

<text 
  label="Survey_Time"
  cond="0"
  size="30"
  translateable="0"
  where="execute,survey,report,notdp">
  <title>Survey Time</title>
  <row label="Start"/>
  <row label="End"/>
  <row label="Total"/>
  <row label="Total_Seconds"/>
  <row label="Total_Minutes"/>
</text>

<suspend/>

<exec when="started">
#######################################
# Local  Time Start
#######################################

currentDate = datetime.datetime.utcnow()

InterviewStartTime =  currentDate + datetime.timedelta(hours=8)         # SG/HK Time
InterviewStartTime = InterviewStartTime.strftime('%m/%d/%Y %H:%M:%S')   # SG/HK Time Format

# InterviewStartTime =  currentDate + datetime.timedelta(hours=9)         # JP/KR Time
# InterviewStartTime = InterviewStartTime.strftime('%Y/%m/%d %H:%M:%S')   # JP/KR Time Format

xLocalTime.Start.val = InterviewStartTime
</exec>

<exec when="finished">
#######################################
# Local  Time End
#######################################

currentDate = datetime.datetime.utcnow()

InterviewEndTime =  currentDate + datetime.timedelta(hours=8)       # SG/HK Time
InterviewEndTime = InterviewEndTime.strftime('%m/%d/%Y %H:%M:%S')   # SG/HK Time Format

# InterviewEndTime =  currentDate + datetime.timedelta(hours=9)       # JP/KR Time
# InterviewEndTime = InterviewEndTime.strftime('%Y/%m/%d %H:%M:%S')   # JP/KR Time Format

xLocalTime.End.val = InterviewEndTime
</exec>

<text 
  label="xLocalTime"
  cond="0"
  fwidth="2048"
  size="40"
  translateable="0"
  where="execute,survey,report">
  <title>Interview Time</title>
  <row label="Start"/>
  <row label="End"/>
</text>

<suspend/>

<html label="rnEndOfSurvey" cond="gv.survey.root.state.testing" translateable="0" where="survey">Thanks for completing the survey. This page is shown for testing only. Please close the window to exit.</html>

<suspend/>

<text 
  label="hQualityScoreAnalyze"
  cond="p.qs['on']==1"
  pii="4"
  size="25"
  translateable="0">
  <title><img src="//d2n88fe5uqdqty.cloudfront.net/rnd/template/loader.gif" /></title>
  <row label="r1" ss:rowClassNames="qsScore">Score</row>
  <row label="r2" ss:rowClassNames="qsStraightlineRanking">StraightlineRanking</row>
  <row label="r3" ss:rowClassNames="qsSpeedingRanking">SpeedingRanking</row>
  <row label="r4" ss:rowClassNames="qsRASRanking">RASRanking</row>
  <row label="r5" ss:rowClassNames="qsPages">Pages</row>
  <row label="r6" ss:rowClassNames="qsDistinctPages">DistinctPages</row>
  <row label="r7" ss:rowClassNames="qsStraightlineCount">StraightlineCount</row>
  <row label="r8" ss:rowClassNames="qsMatrixQuestionCount">MatrixQuestionCount</row>
  <row label="r9" ss:rowClassNames="qsMatrixStraightlineStatuses">MatrixStraightlineStatuses</row>
  <row label="r10" ss:rowClassNames="qsRASAverage">RASAverage</row>
  <row label="r11" ss:rowClassNames="qsOpenEndsAnswered">OpenEndsAnswered</row>
  <row label="r12" ss:rowClassNames="qsOpenEndScores">OpenEndScores</row>
  <row label="r13" ss:rowClassNames="qsRVid">RVid</row>
  <row label="r14" ss:rowClassNames="qsTransactionGuid">TransactionGuid</row>
  <row label="r15" ss:rowClassNames="qsAccelerationRanking">AccelerationRanking</row>
  <row label="r16" ss:rowClassNames="qsVelocityRanking">VelocityRanking</row>
  <row label="r17" ss:rowClassNames="qsRedoRanking">RedoRanking</row>
  <row label="r18" ss:rowClassNames="qsInactivityRanking">InactivityRanking</row>
  <row label="r19" ss:rowClassNames="qsOutlierGroups">OutlierGroups</row>
  <row label="r20" ss:rowClassNames="qsMode">Mode</row>
  <row label="r21" ss:rowClassNames="qsOpenEndFlags">OpenEndFlags</row>
  <row label="r99" ss:rowClassNames="qsRaw">Raw</row>
  <style name="question.after"><![CDATA[
<style>.answers { display:none; }</style>
<input type="hidden" id="qualityscore_collect_disabled">
<script>
$ (document).ready(function(){
              var submitted = 0;
              $ ("#btn_continue, #btn_finish").hide();
    function submitForm(){
      if(!$ ('.qsRaw').find('input').val())
        $ ('.qsRaw').find('input').val("timeout");
      if(!submitted){
        submitted = 1;
        $ ("#btn_continue, #btn_finish").click().show();
      }
    }
              
              setTimeout(submitForm, 5000);
              
    try{
      imperium_qualityscore.AnalyzeData(AnalyzeDataReponse);
    }
    catch(e){
      console.error(e);
      submitForm();
    }
              
              function AnalyzeDataReponse(jsonData) {
      if(${1 if gv.survey.root.state.testing else 0}){
        console.log(JSON.stringify(jsonData));
      }
                try{      
                  $ ('.qsRaw').find('input').val(JSON.stringify(jsonData));
                             if (jsonData.StatusCode == 200)
                             {
                                           for(var key in jsonData){
                                             if(typeof jsonData[key] !== 'object'){
                                                $ ('.qs' + key).find('input').val(jsonData[key]);
                                             }
                                             else{
                                                $ ('.qs' + key).find('input').val(JSON.stringify(jsonData[key]));
                                             }
                                           }             
                             }
                }
                catch(e){
                  $ ('.qsRaw').find('input').val(e.message);
                  console.error(e)
                };
                submitForm()
              }
})
</script>
]]></style>
</text>

<suspend/>

<block label="blkTimeTracking" builder:title="To track time respondent spent">
  <exec>
#set time and LOI

tplSubmitTime.r6.val = round(timeSpent())
tplSubmitTime.r7.val = rnGetTimerTime(p) 
tplSubmitTime.r8.val = round(time.time() - start_timestamp.val)

preciseSum = tplSubmitTime.r2.ival
timeSpentSum = tplSubmitTime.r6.ival
totalSum = tplSubmitTime.r8.ival

if timeSpentSum &gt; preciseSum:
  loiTime = int(timeSpentSum - tplSubmitTime.r3.ival + tplSubmitTime.r7.ival)
else:
  loiTime = int(totalSum - tplSubmitTime.r3.ival)
  
LOI.val = loiTime
  </exec>

  <number 
   label="start_timestamp"
   cond="tplShow()"
   size="15"
   translateable="0"
   where="execute,survey,notdp">
    <title>survey starting timestamp</title>
  </number>

  <float 
   label="tplSubmitTime"
   cond="tplShow()"
   size="10"
   translateable="0"
   where="execute,survey,notdp">
    <title>Tracking submit time. time from preciseTime doesn't include loading time (seconds)</title>
    <row label="r1">preciseTime: Number of pages submitted</row>
    <row label="r2">preciseTime: Sum of time spent on each page(s)</row>
    <row label="r3">preciseTime: Sum of time over page time limit</row>
    <row label="r4">preciseTime: mean of time spent on each page</row>
    <row label="r5">preciseTime: median of time spent on each page</row>
    <row label="r6">timeSpent()</row>
    <row label="r7">Time tracked by rnTimer</row>
    <row label="r8">Total time(end time - start time)</row>
  </float>

  <number 
   label="LOI"
   cond="tplShow()"
   size="10"
   translateable="0"
   where="execute,survey,notdp">
    <title>LOI (seconds)</title>
  </number>
</block>

<suspend/>

<block label="blkQualityChecks" builder:title="Quality Checks" sst="0">
  <exec>
#######################################
# Speeder Auto Check Settings:
#######################################

tplSpeederAutoCheckSettings.r0.val = '1' #On/Off settings (1 = On, 2 = Off) - this check On by default
tplSpeederAutoCheckSettings.r1.val = '0.3' #Percentage of Median time used to check speeder
tplSpeederAutoCheckSettings.r2.val = '30' #Minimum completes to start auto check
tplSpeederAutoCheckSettings.r3.val = '1000' #Maximum completes used to calculate Median time

#######################################
# Straightliner Check Settings:
#######################################

tplStraightlinerSettings.r0.val = '2' #On/Off settings (1 = On, 2 = Off) - this check Off by default

#####
# adjust other Straightliner Settings in isStraightliner() function 
#######################################
  </exec>

  <text 
   label="tplSpeederAutoCheckSettings"
   cond="tplShow()"
   randomize="0"
   size="25"
   translateable="0"
   where="execute,survey,notdp">
    <title>Speeder Auto Check Settings:</title>
    <row label="r0">AutoCheck Speeder On/Off settings</row>
    <row label="r1">Percentage of Median time used to check racer</row>
    <row label="r2">Minimum completes to start auto check</row>
    <row label="r3">Maximum completes used to calculate Median time</row>
  </text>

  <text 
   label="tplStraightlinerSettings"
   cond="tplShow()"
   randomize="0"
   size="25"
   translateable="0"
   where="execute,survey,notdp">
    <title>Straightliner Settings:</title>
    <row label="r0">Straightliner Check On/Off settings</row>
  </text>

  <suspend/>

  <block label="blkSpeederAutoCheckAPI" cond="(tplSpeederAutoCheckSettings.r0.val == '1' and gv.survey.root.state.live)" builder:title="Speeder Auto Check API Call">
    <exec>
#check if average of time per page availabe
curPid= gv.survey.path
if tplSubmitTime.r4.ival &gt; 0:
  tt = tplSubmitTime.r4.ival
  curPid = curPid + "avg"
else:
  tt = LOI.ival

mc = int(tplSpeederAutoCheckSettings.r3.val)
medianTime.r3.val = tt

server = getHostId(gv)
p.speederDict = dict(pnum=curPid,ss=server,rid=record,tt=tt,mc=mc)
    </exec>

    <logic label="speederAutoCheckAPI" api:params="p.speederDict" api:url="https://speeders.researchnow.com/spdrchk/gbtSpeedTest.php" uses="api.1"/>
    <exec>
if speederAutoCheckAPI.status == 200:
    outputAPI = json_loads(speederAutoCheckAPI.r[1:-2])
    medianTime.r1.val = outputAPI['medianTime']
    medianTime.r2.val = outputAPI['completes']
    isSpeederAutoCheck()
else:
    speederAutoCheck.val = speederAutoCheck.r3.index
    </exec>

    <text 
    label="medianTime"
    cond="tplShow()"
    randomize="0"
    size="25"
    translateable="0"
    where="execute,survey,notdp">
      <title>medianTime</title>
      <row label="r1">medianTime</row>
      <row label="r2">medianCompletes</row>
      <row label="r3">time used for speeder check</row>
    </text>
  </block>

  <exec>
#######################################
# Run Quality Checks  
#######################################
isStraightliner()
isSpeeder()
isSlowpoke()
  </exec>

  <block label="blkQualityCheckTracking" cond="tplShow()" builder:title="Quality Check Tracking Questions">
    <radio 
    label="straightlinerCheck"
    optional="1"
    randomize="0"
    translateable="0"
    where="execute,survey,notdp">
      <title>Straightliner Check</title>
      <row label="r1">Failed</row>
      <row label="r2">Passed</row>
    </radio>

    <radio 
    label="speederAuto"
    optional="1"
    randomize="0"
    translateable="0"
    where="execute,survey,notdp">
      <title>Speeder Check</title>
      <row label="r1">Failed</row>
      <row label="r2">Passed</row>
    </radio>

    <radio 
    label="speederAutoCheck"
    optional="1"
    randomize="0"
    translateable="0"
    where="execute,survey,notdp">
      <title>Speeder Auto Check</title>
      <row label="r1">Failed</row>
      <row label="r2">Passed</row>
      <row label="r3">Server Call Failed</row>
    </radio>

    <radio 
    label="slowpokeCheck"
    optional="1"
    randomize="0"
    translateable="0"
    where="execute,survey,notdp">
      <title>Slowpoke Check</title>
      <row label="r1">Failed</row>
      <row label="r2">Passed</row>
    </radio>
  </block>

  <suspend/>

  <exec>
#######################################
# drop marker  
#######################################

if straightlinerCheck.r1:
	setMarker('straightlinerAuto')

elif speederAuto.r1:
	setMarker('speederAuto')

elif speederAutoCheck.r1:
	setMarker('speederAutoCheck')
	
elif slowpokeCheck.r1:
	setMarker('slowpokeAuto')
	
elif p.qs['term']==1:
	try:
		if tm != '1' and hQualityScoreAnalyze.r1.any and float(hQualityScoreAnalyze.r1.val) lt 20:
			setMarker('qualityScore')
	except:	pass
  </exec>

  <suspend/>

  <term label="Term_Speeder_Check_Failed" cond="hasMarker('speederAuto')">Speeder Check Failed</term>

  <term label="Term_Speeder_Auto_Check_Failed" cond="hasMarker('speederAutoCheck')">Speeder Auto Check Failed</term>

  <term label="Term_SlowPoke_Check_Failed" cond="hasMarker('slowpokeAuto')">SlowPoke Check Failed</term>

  <term label="Term_Straightliner_Check_Failed" cond="hasMarker('straightlinerAuto')">Straightliner Check Failed</term>

  <term label="Term_Verbatim_Check_Failed" cond="hasMarker('badopenAuto')">Verbatim Check Failed</term>

  <term label="Term_Quality_Check_Failed" cond="hasMarker('failedAuto')">Quality Check Failed</term>

  <term label="QualityScoreCheckTerm" cond="hasMarker('qualityScore')">QualityScore Check Failed</term>

  <suspend/>

  <exec when="init">
#######################################
# Quality Checks Functions
#######################################



def isStraightliner():
    if tplStraightlinerSettings.r0.val == '1':
        #######################################
        # Update straightliner check settings
        #######################################

        questions = [q4, q5, q6]               ##### grids to checks
        numbRequiredGridsToFail = 1       ##### number of grids respondent need to fail at
        
        #######################################     
        # Example how to add other checks   
        ####################################### 
        #otherFailed = 0
        #if not q1.r1.c2:
        #   otherFailed = 1
        
        straightlinerCheck.val = straightlinerCheck.r2.index
        
        gridsFailed = 0
        for q in questions:
            sl = True
            pval = None
            rowcount = 0
            for r in q.rows: 
                if r.any:
                    if  pval is not None and r.val != pval:   # not first answered row
                        sl = False
                        break
                    pval = r.val
                    rowcount += 1

            if rowcount &gt; 1 and sl:           #if more than 1 row and straightliner
                gridsFailed += 1
                     
        #######################################     
        # Example how to add other checks to condition
        ####################################### 
        # if gridsFailed &gt;= numbRequiredGridsToFail or otherFailed:
                                
        if gridsFailed &gt;= numbRequiredGridsToFail:
            straightlinerCheck.val = straightlinerCheck.r1.index
            

def isSpeeder():  
    quota_cells = gv.survey.root.quota.getQuotaCells()
    current, limit, overquota = quota_cells["/Settings/Seconds"]
    p.minTime = limit
    
    speederAuto.val = speederAuto.r2.index

    if timeSpent() lt p.minTime:
        speederAuto.val = speederAuto.r1.index

def isSpeederAutoCheck():

	current, limit, overquota = gv.survey.root.quota.getQuotaCells()["/Settings/Seconds"]
    
	if limit == 0:
		speederAutoCheck.val = speederAutoCheck.r2.index 

		if int(medianTime.r2.val) &gt;= int(tplSpeederAutoCheckSettings.r2.val): #check # of completes to date
			mTime = int(medianTime.r1.val) * float(tplSpeederAutoCheckSettings.r1.val) #check median time
			print "mTIME:"
			print mTime

			if float(medianTime.r3.val) lt mTime:
				speederAutoCheck.val = speederAutoCheck.r1.index

def isSlowpoke():
    from datetime import datetime
	
    quota_cells = gv.survey.root.quota.getQuotaCells()
    current, limit, overquota = quota_cells["/Settings/Hours"]
    maxTime = limit * 3600
    
    fmt = '%m/%d/%Y %H:%M'

    start_time = datetime.strptime(start_date.unsafe_val, fmt)
    end_time = datetime.now()

    slowpokeCheck.val = slowpokeCheck.r2.index
    
    if maxTime != 0 and (end_time - start_time).total_seconds() gt maxTime:
        slowpokeCheck.val = slowpokeCheck.r1.index
    
#######################################
# Utility Functions
#######################################
def tplShow():
	return settings=='test' or gv.survey.root.state == 'live'
	
# 
#######################################
  </exec>
</block>
</survey>