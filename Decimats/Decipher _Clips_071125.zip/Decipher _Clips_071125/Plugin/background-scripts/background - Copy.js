const rules = {
  "codemirror.js": "https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.44.0/codemirror.js",
  "codemirror.css": "https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.44.0/codemirror.css",
  "lumos/xmleditor/main.js": chrome.runtime.getURL("content-scripts/xmleditor.js"),
  "lumos/xmleditor/main.css": chrome.runtime.getURL("content-scripts/xmleditor.css"),
  "apps/static/lumos/images/spinner_1.gif": chrome.runtime.getURL("res/loader.gif"),
}

chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    var redirect = null;
    for(var url in rules) {
      if(RegExp(url).test(details.url)) {
        redirect = rules[url];
        break;
      }
    }
    return { redirectUrl: redirect };
  },
  {
    urls: [
      "<all_urls>"
    ]
  },
  ["blocking"]
);
