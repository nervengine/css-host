chrome.runtime.onInstalled.addListener(() => {
  console.log("Decipher Clips Extension installed.");
});