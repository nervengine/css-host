$(window).load(function(e) {
    var editor = window.codemirror
    var decipherClips = window.decipherclips
    
    function openHelperDialog(editor, hintText, callback) {
        var template = "<span class='CodeMirror-search-hint'>"
        template += hintText
        template += "</span>"
        template += "<input type='text'/>"
        editor.openDialog(template, callback, {})
    }
    
    $.contextMenu({
        selector: '.CodeMirror',
        zIndex: 100,
        items: {
            cut: {
                name: "Cut",
                icon: "cut",
                callback: function() {
                    var clipboardSupported = navigator.clipboard
                    if(clipboardSupported) {
                         navigator.clipboard.writeText(editor.getSelection())
                        .then(() => {
                            editor.replaceSelection("")
                        })
                        .catch(() => {
                            alert("Command failed")
                        })
                    } else {
                        alert("This feature is not supported by your browser.")
                    }
                }
            },
            copy: {
                name: "Copy",
                icon: "copy",
                callback: function() {
                    var clipboardSupported = navigator.clipboard
                    if(clipboardSupported) {
                        navigator.clipboard.writeText(editor.getSelection())
                        .then(() => {
                        })
                        .catch(() => {
                            alert("Command failed")
                        })
                    } else {
                        alert("This feature is not supported by your browser.")
                    }
                }
            },
            paste: {
                name: "Paste",
                icon: "paste",
                callback: function() {
                    var clipboardSupported = navigator.clipboard
                    if(clipboardSupported) {
                        navigator.clipboard.readText()
                        .then(text => {
                            editor.replaceSelection(text)
                        })
                        .catch(() => {
                            alert("Command failed")
                        })
                    } else {
                        alert("This feature is not supported by your browser.")
                    }
                }
            },
            RowMenu: {
                name: "Rows",
                items: {
                    MakeRows: {
                        name: "Make rows",
                        callback: function() {
                            decipherClips.makeRows()
                        }
                    },
                    MakeRowsLowToHigh: {
                      name: "Make rows L-H",
                      callback: function() {
                        decipherclips.makeRowsLowToHigh()
                      }
                    },
                    MakeRowsHighToLow: {
                      name: "Make rows H-L",
                      callback: function() {
                        decipherclips.makeRowsHighToLow()
                      }
                    },
                    MakeRowsMatchLabel: {
                        name: "Make rows match label",
                        callback: function() {
                            decipherClips.makeRowsMatchLabel()
                        }
                    },
                    MakeRowsMatchValues: {
                        name: "Make rows match values",
                        callback: function() {
                            decipherClips.makeRowsMatchValues()
                        }
                    },
                ConvertToRows: {
                  name: "Convert elements to rows",
                  callback: function() {
                    decipherClips.convertToRows()
                  }
                }
                }
            },
            ColMenu: {
                name: "Columns",
                items: {
                    MakeCols: {
                        name: "Make columns",
                        callback: function() {
                            decipherClips.makeCols()
                        }
                    },
                    MakeColsLowToHigh: {
                      name: "Make columns L-H",
                      callback: function() {
                        decipherclips.makeColsLowToHigh()
                      }
                    },
                    MakeColsHighToLow: {
                      name: "Make columns H-L",
                      callback: function() {
                        decipherclips.makeColsHighToLow()
                      }
                    },
                    MakeColsMatchLabel: {
                        name: "Make columns match label",
                        callback: function() {
                            decipherClips.makeColsMatchLabel()
                        }
                    },
                    MakeColsMatchValues: {
                        name: "Make columns match values",
                        callback: function() {
                            decipherClips.makeColsMatchValues()
                        }
                    },
                ConvertToCols: {
                  name: "Convert elements to columns",
                  callback: function() {
                    decipherClips.convertToCols()
                  }
                }
                }
            },
            ChoiceMenu: {
                name: "Choice",
                items: {
                    MakeChoices: {
                        name: "Make choices",
                        callback: function() {
                            decipherClips.makeChoices()
                        }
                    },
                    MakeChoicesLowToHigh: {
                      name: "Make choices L-H",
                      callback: function() {
                        decipherclips.makeChoicesLowToHigh()
                      }
                    },
                    MakeChoicesHighToLow: {
                      name: "Make choices H-L",
                      callback: function() {
                        decipherclips.makeChoicesHighToLow()
                      }
                    },
                    MakeChoicesMatchLabel: {
                        name: "Make choice match label",
                        callback: function() {
                            decipherClips.makeChoicesMatchLabel()
                        }
                    },
                    MakeChoicesMatchValues: {
                        name: "Make choices match values",
                        callback: function() {
                            decipherClips.makeChoicesMatchValues()
                        }
                    },
                ConvertToChoices: {
                  name: "Convert element to choices",
                  callback: function() {
                    decipherClips.convertToChoices()
                  }
                }
                }
            },
            NoAnswer: {
                name: "No Answer",
                items: {
                    MakeNoAnswer: {
                        name: "Make no answer",
                        callback: function() {
                            decipherclips.makeNoAnswer()
                        }
                    },
                    MakeNoAnswerMatchLabel: {
                        name: "Make no answer match label",
                        callback: function() {
                            decipherclips.makeNoAnswerMatchLabel()
                        }
                    },
                    ConvertToNoAnswer: {
                        name: "Convert to no answer",
                        callback: function() {
                            decipherclips.convertToNoAnswer()
                        }
                    }
                }
            },
            Groups: {
                name: "Group",
                items: {
                    MakeGroups: {
                        name: "Make groups",
                        callback: function() {
                            decipherClips.makeGroups()
                        }
                    },
                    AssignGroup: {
                        name: "Assign group",
                        callback: function() {
                            openHelperDialog(editor, "Enter group to assign", function(e) {
                                decipherClips.assignGroup(e)
                            })
                        }
                    },
                    RemoveGroup: {
                        name: "Remove group",
                        callback: function() {
                            decipherClips.removeGroup()
                        }
                    }
                }
            },
            QuestionsMenu: {
                name: "Questions",
                items: {
                    Radio: {
                        name: "Radio",
                        icon: "fa-dot-circle",
                        callback: function() {
                            decipherClips.makeRadio()
                        }
                    },
                    Checkbox: {
                        name: "Checkbox",
                        callback: function() {
                            decipherClips.makeCheckbox()
                        }
                    },
                    Select: {
                        name: "Select",
                        callback: function() {
                            decipherClips.makeSelect()
                        }
                    },
                    Textbox: {
                        name: "Textbox",
                        callback: function() {
                            decipherClips.makeText()
                        }
                    },
                    TextArea: {
                        name: "TextArea",
                        callback: function() {
                            decipherClips.makeTextArea()
                        }
                    },
                    Number: {
                        name: "Number",
                        callback: function() {
                            decipherClips.makeNumber()
                        }
                    },
                    Float: {
                        name: "Float",
                        callback: function() {
                            decipherclips.makeFloat()
                        }
                    },
                    DatePicker: {
                        name: "DatePicker",
                        callback: function() {
                            decipherclips.makeDatePicker()
                        }
                    },
                    SliderRating: {
                        name: "Slider Rating",
                        callback: function() {
                            decipherclips.makeSliderRating()
                        }
                    },
                    HTML: {
                        name: "HTML",
                        callback: function() {
                    openHelperDialog(editor, "Enter label", function(e) {
                        decipherClips.makeHTML(e)
                    })
                        }
                    },
                    Block: {
                        name: "Block",
                        callback: function() {
                    openHelperDialog(editor, "Enter group to assign", function(e) {
                        decipherClips.makeBlock(e)
                    })
                        }
                    },
                    Loop: {
                        name: "Loop",
                        callback: function() {
                            decipherClips.makeLoop()
                        }
                    }
                }
            },
            ElementAttributes: {
                name: "Element Attributes",
                items: {
                    AddExclusiveAttribute: {
                        name: "Add exclusive attribute",
                        callback: function() {
                            decipherClips.addExclusiveAttribute()
                        }
                    },
                    RemoveExclusiveAttribute: {
                        name: "Remove exclusive attribute",
                        callback: function() {
                            decipherclips.removeExclusiveAttribute()
                        }
                    },
                    AddOpenAttribute: {
                        name: "Add open attribute",
                        callback: function() {
                            decipherclips.addOpenAttribute()
                        }
                    },
                    RemoveOpenAttribute: {
                        name: "Remove open attribute",
                        callback: function() {
                            decipherclips.removeOpenAttribute()
                        }
                    },
                    AddCond: {
                        name: "Add cond attribute",
                        callback: function() {
                            openHelperDialog(editor, "Enter condition logic", function(e) {
                                decipherClips.addCond(e)
                            })
                        }
                    },
                    RemoveCond: {
                        name: "Remove cond attribute",
                        callback: function() {
                            decipherClips.removeCond()
                        }
                    },
                    AddValues: {
                        name: "Add value attribute",
                        callback: function() {
                            decipherClips.addValues()
                        }
                    },
                    RemoveValues: {
                        name: "Remove value attribute",
                        callback: function() {
                            decipherClips.removeValues()
                        }
                    }
                }
            },
            Other: {
                name: "Other",
                items: {
                    ReverseString: {
                        name: "Reverse string",
                        callback: function() {
                            decipherclips.reverseString()
                        }
                    },
                    MakeComment: {
                      name: "Make comment",
                      callback: function() {
                        decipherclips.makeComment()
                      }
                    },
                    MakeDefine: {
                        name: "Make defines",
                        callback: function() {
                           openHelperDialog(editor, "Enter label", function(e) {
                                decipherClips.makeDefine(label)
                            })
                        }
                    },
                    MakeCases: {
                        name: "Make cases",
                        callback: function() {
                            decipherClips.makeCases()
                        }
                    },
                    MakePipe: {
                        name: "Make pipe",
                        callback: function() {
                            openHelperDialog(editor, "Enter label", function(e) {
                                decipherClips.makePipe(label)
                            })
                        }
                    },
                    WrapTag: {
                        name: "Wrap with tag",
                        callback: function() {
                            openHelperDialog(editor, "Enter tag", function(e) {
                                decipherClips.wrapTag(e)
                            })
                        }
                    },
                }
            }
        }
    });
});