const rules = [
  { type: "css", url: "vendor/codemirror/addon/fold/foldgutter.css"},   
  { type: "css", url: "vendor/codemirror/addon/hint/show-hint.css"},
  { type: "css", url: "vendor/codemirror/addon/hint/show-hint.css"},  
  { type: "css", url: "vendor/codemirror/theme/3024-day.css" },
  { type: "css", url: "vendor/codemirror/theme/3024-night.css" },
  { type: "css", url: "vendor/codemirror/theme/abcdef.css" },
  { type: "css", url: "vendor/codemirror/theme/ambiance-mobile.css" },
  { type: "css", url: "vendor/codemirror/theme/ambiance.css" },
  { type: "css", url: "vendor/codemirror/theme/base16-dark.css" },
  { type: "css", url: "vendor/codemirror/theme/base16-light.css" },
  { type: "css", url: "vendor/codemirror/theme/bespin.css" },
  { type: "css", url: "vendor/codemirror/theme/blackboard.css" },
  { type: "css", url: "vendor/codemirror/theme/cobalt.css" },
  { type: "css", url: "vendor/codemirror/theme/colorforth.css" },
  { type: "css", url: "vendor/codemirror/theme/darcula.css" },
  { type: "css", url: "vendor/codemirror/theme/dracula.css" },
  { type: "css", url: "vendor/codemirror/theme/duotone-dark.css" },
  { type: "css", url: "vendor/codemirror/theme/duotone-light.css" },
  { type: "css", url: "vendor/codemirror/theme/eclipse.css" },
  { type: "css", url: "vendor/codemirror/theme/elegant.css" },
  { type: "css", url: "vendor/codemirror/theme/erlang-dark.css" },
  { type: "css", url: "vendor/codemirror/theme/gruvbox-dark.css" },
  { type: "css", url: "vendor/codemirror/theme/hopscotch.css" },
  { type: "css", url: "vendor/codemirror/theme/icecoder.css" },
  { type: "css", url: "vendor/codemirror/theme/idea.css" },
  { type: "css", url: "vendor/codemirror/theme/isotope.css" },
  { type: "css", url: "vendor/codemirror/theme/lesser-dark.css" },
  { type: "css", url: "vendor/codemirror/theme/liquibyte.css" },
  { type: "css", url: "vendor/codemirror/theme/lucario.css" },
//  { type: "css", url: "vendor/codemirror/theme/material-darker.css" },
//  { type: "css", url: "vendor/codemirror/theme/material-ocean.css" },
//  { type: "css", url: "vendor/codemirror/theme/material-palenight.css" },
  { type: "css", url: "vendor/codemirror/theme/material.css" },
  { type: "css", url: "vendor/codemirror/theme/mbo.css" },
  { type: "css", url: "vendor/codemirror/theme/mdn-like.css" },
  { type: "css", url: "vendor/codemirror/theme/midnight.css" },
  { type: "css", url: "vendor/codemirror/theme/monokai.css" },
//  { type: "css", url: "vendor/codemirror/theme/moxer.css" },
  { type: "css", url: "vendor/codemirror/theme/neat.css" },
  { type: "css", url: "vendor/codemirror/theme/neo.css" },
  { type: "css", url: "vendor/codemirror/theme/night.css" },
  { type: "css", url: "vendor/codemirror/theme/nord.css" },
  { type: "css", url: "vendor/codemirror/theme/oceanic-next.css" },
  { type: "css", url: "vendor/codemirror/theme/panda-syntax.css" },
  { type: "css", url: "vendor/codemirror/theme/paraiso-dark.css" },
  { type: "css", url: "vendor/codemirror/theme/paraiso-light.css" },
  { type: "css", url: "vendor/codemirror/theme/pastel-on-dark.css" },
  { type: "css", url: "vendor/codemirror/theme/railscasts.css" },
  { type: "css", url: "vendor/codemirror/theme/rubyblue.css" },
  { type: "css", url: "vendor/codemirror/theme/seti.css" },
  { type: "css", url: "vendor/codemirror/theme/shadowfox.css" },
  { type: "css", url: "vendor/codemirror/theme/solarized.css" },
  { type: "css", url: "vendor/codemirror/theme/ssms.css" },
  { type: "css", url: "vendor/codemirror/theme/the-matrix.css" },
  { type: "css", url: "vendor/codemirror/theme/tomorrow-night-bright.css" },
  { type: "css", url: "vendor/codemirror/theme/tomorrow-night-eighties.css" },
  { type: "css", url: "vendor/codemirror/theme/ttcn.css" },
  { type: "css", url: "vendor/codemirror/theme/twilight.css" },
  { type: "css", url: "vendor/codemirror/theme/vibrant-ink.css" },
  { type: "css", url: "vendor/codemirror/theme/xq-dark.css" },
  { type: "css", url: "vendor/codemirror/theme/xq-light.css" },
  { type: "css", url: "vendor/codemirror/theme/yeti.css" },
//  { type: "css", url: "vendor/codemirror/theme/yonce.css" },
  { type: "css", url: "vendor/codemirror/theme/zenburn.css" },
  { type: "css", url: "content-scripts/ui.fancytree.min.css" },
  { type: "css", url: "content-scripts/jquery.contextMenu.min.css"},
  { type: "javascript", url: "content-scripts/jquery.fancytree-all.min.js"},
  { type: "javascript", url: "content-scripts/jquery.contextMenu.min.js"},
  { type: "javascript", url: "content-scripts/jquery.ui.position.js"},
  { type: "javascript", url: "vendor/codemirror/addon/selection/active-line.js"},
  { type: "javascript", url: "vendor/codemirror/addon/edit/closetag.js"},
  { type: "javascript", url: "vendor/codemirror/addon/edit/closebrackets.js"},
  { type: "javascript", url: "vendor/codemirror/addon/fold/foldgutter.js"},    
  { type: "javascript", url: "vendor/codemirror/addon/fold/foldcode.js"},
  { type: "javascript", url: "vendor/codemirror/addon/hint/show-hint.js"},
  { type: "javascript", url: "vendor/codemirror/addon/hint/xml-hint.js"},
  { type: "javascript", url: "vendor/codemirror/addon/fold/xml-fold.js"},
  { type: "javascript", url: "vendor/codemirror/addon/fold/comment-fold.js"},
  { type: "javascript", url: "vendor/codemirror/addon/fold/brace-fold.js"},
  { type: "javascript", url: "vendor/codemirror/addon/fold/indent-fold.js"},
  { type: "javascript", url: "vendor/codemirror/addon/fold/markdown-fold.js"},
  { type: "javascript", url: "content-scripts/decipher-context-menu.js"},
  { type: "javascript", url: "content-scripts/decipher-code-completion.js"},
  { type: "javascript", url: "content-scripts/decipher-clips-settings.js"}
];

rules.forEach(rule => {
  const url = chrome.runtime.getURL(rule.url);

  // Optional live file test (shows 404s in console)
  fetch(url)
    .then(res => {
      if (!res.ok) {
        console.error(`❌ MISSING FILE: ${rule.url}`);
      } else {
        console.log(`✅ LOADED: ${rule.url}`);
      }
    });

  if (rule.type === "css") {
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href = url;
    document.head.appendChild(link);
  } else if (rule.type === "javascript") {
    const script = document.createElement("script");
    script.src = url;
    script.defer = true;
    document.body.appendChild(script);
  }
});