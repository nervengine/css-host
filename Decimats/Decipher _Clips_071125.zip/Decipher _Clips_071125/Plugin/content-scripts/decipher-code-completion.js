// Wait until DOM is ready
window.addEventListener("DOMContentLoaded", () => {
  const textarea = document.getElementById("editor");

  if (!textarea) {
    console.warn("❗ No <textarea id='editor'> found for CodeMirror setup.");
    return;
  }

  const editor = CodeMirror.fromTextArea(textarea, {
    mode: "xml",
    lineNumbers: true,
    extraKeys: { "Ctrl-Space": "autocomplete" },
    hintOptions: {
      schemaInfo: tags
    }
  });

  const autoCompleteKeymap = {
    "'<'": completeAfter,
    "'/'": completeIfAfterLt,
    "' '": completeIfInTag,
    "'='": completeIfInTag,
    "\"": completeIfInTag
  };

  editor.addKeyMap(autoCompleteKeymap);

  // Optional: expose for debugging
  window.codemirrorEditor = editor;
});

var questionElements = ["col", "row", "choice"]

var questionAttributes = {
  adim: ["rows","cols","choices","auto"],
  aggregate: null,
  alt: null,
  altLabel: null,
  averages: ["none","rows","cols","choices","nosummary","summary"],
  below: null,
  blankIfZero: ["1", "0"],
  blankValue: ["1", "0"],
  choiceCond: null,
  choiceGroups: ["report","survey","restrict"],
  choiceShuffle: ["flip","rflip","rotate","reverse-rotate","rrotate"],
  colCond: null,
  colGroups: ["report","survey","restrict"],
  colLegend: ["default","none","both","top","bottom","group","beforeGroup"],
  colLegendRows: null,
  colShuffle: ["flip","rflip","rotate","reverse-rotate","rrotate"],
  cond: null,
  comment: null,
  dataSource: null,
  dataRef: null,
  exec: null,
  grouping: null,
  horizontalPercentages: ["1", "0"],
  keepWith: null,
  label: null,
  noTranslate: ["title","comment"],
  open: ["default","left","right"],
  optional: ["1", "0"],
  pii: null,
  ratingDirection: ["default","reverse"],
  rightOf: null,
  rowCond: null,
  rowGroups: ["report","survey","restrict"],
  rowLegend: ["default","both","right","left"],
  rowShuffle: ["flip","rflip","rotate","reverse-rotate","rrotate"],
  showSource: ["1", "0"],
  shuffle: ["none","rows","cols","choices"],
  shuffleBy: null,
  sort: ["none","rows","cols","choices","desc","asc","percentages"],
  sortChoices: ["none","asc","desc","survey","report"],
  sortCols: ["none","asc","desc","survey","report"],
  sortRows: ["none","asc","desc","survey","report"],
  style: null,
  title: null,
  type: ["none","rating"],
  uses: null,
  values: ["none","order"],
  where: ["survey","report","summary","none","notdp", "execute"],
  tv: ["auto","off","force"],
  translateable: ["1", "0"],
  randomize: ["1", "0"],
  disabled: ["1", "0"],
  verify: ["len(MIN_LENGTH, MAX_LENGTH)","range(MINIMUM, MAXIMUM)","zipcode","phoneUS","digits","number","email","zipcodeExt"],
  daterange: "daterange(FORMAT, START, END)",
  uses: ["audio.3", "audiotestimonial.1", "autosum.5", "atmrating.5", "atm1d.9", "atmtable.6", "cardsort.6", "cardrating.1", "fir.2", "separator.5", "imgmap.4", "bcme.6", "multicol.7", "onerowatatime.3", "timertest.3", "pageturner.4", "quester.1", "ranksort.4", "ratingscale.5", "sliderdecimal.3", "slidernumber.5", "sliderpoints.3", "shoppingcart.3", "starrating.5", "hottext.3", "leftright.1", "bcvideo.5", "videoplayer.1", "videoembed.3", "videocapture.1"],
  "ss:rowClassNames": null,
  "ss:colClassNames": null,
  "ss:choiceClassNames": null,
  "ss:questionClassNames": null,
  "ss:commentClassNames": null
}

var styleAttributes = {
  name: [
  "global.page.head",
  "question.header",
  "question.element",
  "respview.client.meta",
  "survey.question",
  "question.left",
  "respview.client.css",
  "survey.question.instructions",
  "question.right",
  "respview.client.js",
  "survey.question.answers.start",
  "el.radio",
  "survey.header",
  "question.group-column",
  "el.checkbox",
  "survey.logo",
  "question.group-column-cell",
  "el.select.header",
  "buttons",
  "question.top-legend",
  "el.select.default",
  "button.continue",
  "question.left-blank-legend",
  "el.select.element",
  "button.finish",
  "question.top-legend-item",
  "el.select.footer",
  "button.cancel",
  "question.right-blank-legend",
  "el.textarea",
  "survey.completion",
  "question.group-3",
  "el.noanswer",
  "survey.respview.footer",
  "question.group-2",
  "el.text",
  "survey.respview.footer.support",
  "question.group",
  "el.open",
  "button.goback",
  "question.row",
  "el.image",
  "page.head",
  "question.col-legend-row",
  "question.col-legend-row-item",
  "question.na.row",
  "question.bottom-legend",
  "question.bottom-legend-item",
  "question.footer",
  "survey.question.answers.end",
  "question.after"
  ],
  label: null,
  copy: null,
  cond: ["0", "1"],
  rows: null,
  cols: null,
  mode: ["instead", "before", "after"],
  with: null,
  wrap: ["ready"]
}

var questionElementsAttributes = {
  open: ["1", "0"],
  openSize: null,
  label: null,
  groups: null,
  value: null,
  exclusive: ["1", "0"],
  aggregate: ["1", "0"],
  percentages: ["1", "0"],
  optional: ["1", "0"],
  range: null,
  okUnique: ["1", "0"],
  openOptional: ["1", "0"],
  colLegend: ["1", "0"],
  extraError: ["1", "0"],
  amount: null,
  size: null,
  averages: ["1", "0"],
  cond: ["1", "0"],
  randomize: ["1", "0"]
}

var checkboxAttributes = {
  atleast: null,
  atmost: null,
  exactly: null,
  pipeMultiple: null,
  groupRestrict: ["none", "cols"]
}

var execAttributes = {
  when: [
  "init",
  "survey",
  "started",
  "virtualInit",
  "finished",
  "returning",
  "verified",
  "virtual",
  "flow",
  "sqlTransfer",
  "sqlTransferInit",
  "submit"
  ],
  cond: null
}   

var selectAttributes = {
  unique: ["none","cols","rows","cols,rows"],
  minRanks: null
}

var quotaAttributes = {
  sheet: null,
  cond: ["0", "1"]
}

var looprowAttributes = {
  label: null,
  cond: null,
  target: null
}

var tags = {
  radio: { attrs: questionAttributes, children: questionElements },
  checkbox: { attrs: Object.assign({}, questionAttributes, checkboxAttributes), children: questionElements },
  select: { attrs: questionAttributes, children: questionElements },
  text: { attrs: questionAttributes, children: questionElements },
  textarea: { attrs: questionAttributes },
  number: { attrs: questionAttributes, children: questionElements },
  row: { attrs: questionElementsAttributes },
  col: { attrs: questionElementsAttributes },
  choice: { attrs: questionElementsAttributes },
  style: { attrs: styleAttributes },
  exec: { attrs: execAttributes },
  quota: { attrs: quotaAttributes },
  looprow: { attrs: looprowAttributes }
};

// --- Completion Handlers ---
function completeAfter(cm, pred) {
  var cur = cm.getCursor();
  if (!pred || pred()) {
    setTimeout(() => {
      if (!cm.state.completionActive) cm.showHint({ completeSingle: false });
    }, 100);
  }
  return CodeMirror.Pass;
}

function completeIfAfterLt(cm) {
  return completeAfter(cm, () => {
    var cur = cm.getCursor();
    return cm.getRange(CodeMirror.Pos(cur.line, cur.ch - 1), cur) == "<";
  });
}

function completeIfInTag(cm) {
  return completeAfter(cm, () => {
    var tok = cm.getTokenAt(cm.getCursor());
    if (tok.type == "string" && (!/['"]/.test(tok.string.charAt(tok.string.length - 1)) || tok.string.length == 1)) return false;
    var inner = CodeMirror.innerMode(cm.getMode(), tok.state).state;
    return inner.tagName;
  });
}



