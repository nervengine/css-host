(function(window, $) {

    var cm = window.codemirror;
    var clips = window.decipherclips;
    var settingsMenu = ["Editor", "Appearance", "Keybinding", "Other"];

    function CreateSettingsModal() {

        var settingsContent = {
            "Editor": CreateEditorSettings(),
            "Appearance": CreateAppearanceSettings(),
            "Keybinding": CreateKeybindingSettings(),
            "Other": CreateOtherSettings()
        };

        var okButton = $("<button>", {
            "class": "btn",
            "type": "button",
            "data-dismiss": "modal",
            "aria-hidden": "true",
            "text": "OK"
        });

        var tabControl = $("<div>", {
            "class": "tabbable tabs-left"
        });

        var tabList = $("<ul>", {
            "class": "nav nav-tabs"
        });

        var tabPages = $("<div>", {
            "class": "tab-content"
        });

        for (var i = 0; i < settingsMenu.length; i++) {

            var tabId = "tab_" + settingsMenu[i].toLowerCase();
            var list = $("<li>").toggleClass("active", i == 0);

            var toggle = $("<a>", {
                "href": "#" + tabId,
                "text": settingsMenu[i],
                "data-toggle": "tab"
            });

            var fixedContainer = $("<div>", {
                    "class": "fixed-container"
            })
            .css({
                "max-height": "250px",
                "min-height": "250px",
                "overflow": "auto"
            });

            var content = $("<div>", {
                    "id": tabId,
                    "class": "tab-pane fade in"
                })
                .toggleClass("active", i == 0);

            fixedContainer.append("<h4>" + settingsMenu[i] + " settings" + "</h4>")
            fixedContainer.append(settingsContent[settingsMenu[i]]);
            content.append(fixedContainer);
            list.append(toggle);
            tabList.append(list);
            tabPages.append(content);
        }

        tabControl.append(tabList);
        tabControl.append(tabPages);

        $("body").append(CreateModal("settingsModal", "Settings", tabControl, okButton));

    }

    function CreateModal(modalId, modalTitle, modalContent, modalFooter) {

        var modal = $("<div>", {
            "id": modalId,
            "class": "modal hide fade",
            "tabindex": "-1",
            "role": "dialog",
            "aria-labelledby": "modalLabel",
            "aria-hidden": "true",
            "data-backdrop": "true"
        });

        var header = $("<div>", {
            "class": "modal-header"
        })

        var closeButton = $("<button>", {
            "type": "button",
            "class": "close",
            "data-dismiss": "modal",
            "aria-hidden": "true",
            "text": "×"
        });

        var title = $("<h4>", {
            "class": "modal-title",
            "text": modalTitle
        });

        var body = $("<div>", {
            "class": "modal-body"
        });

        var footer = $("<div>", {
            "class": "modal-footer"
        });

        header.append(closeButton);
        header.append(title);
        body.append(modalContent);
        footer.append(modalFooter);
        modal.append(header);
        modal.append(body);
        modal.append(footer);

        return modal;
    }

    function CreateSettingsTable(tableId, controls) {

        var table = $("<table>", {
            "id": tableId,
            "class": "table table-striped"
        });

        for (var i = 0; i < controls.length; i++) {

            var localSettings = JSON.parse(localStorage.getItem("editorsettings"));

            var tableRow = $("<tr>", { class: "table-row" });

            var entry = controls[i];

            var cellLabel = $("<td>", {
                "text": entry.label,
                "class": "cell-label"
            });

            var cellControl = $("<td>", {
                "class": "cell-control"
            });

            var cellSwitch = $("<div>", {
                "class": "onoffswitch"
            });

            var cellInput = $("<input>", {
                "id": entry.key,
                "name": entry.key,
                "type": "checkbox",
                "class": "onoffswitch-checkbox",
                "checked": cm.getOption(entry.key),
                "change": function(e) {
                    //Change editor settings
                    cm.setOption(e.currentTarget.name, e.currentTarget.checked);
                    //Get editor settings from local storage
                    var localSettings = JSON.parse(localStorage.getItem("editorsettings"));
                    //Update value in parsed settings
                    localSettings[e.currentTarget.name] = e.currentTarget.checked;
                    //Update local storage editor settings
                    localStorage.setItem("editorsettings", JSON.stringify(localSettings));
                }
            });

            var cellSwitchLabel = $("<label>", {
                "class": "onoffswitch-label",
                "for": entry.key
            });

            cellSwitch.append(cellInput);
            cellSwitch.append(cellSwitchLabel);
            cellControl.append(cellSwitch);
            tableRow.append(cellLabel);
            tableRow.append(cellControl);
            table.append(tableRow);
        }

        return table;
    }

	function CreateEditorSettings(editorInstance) {

		var editorSettings = [
			{ "label": "Line Numbers", "key": "lineNumbers"},
			{ "label": "Line Wrapping", "key": "lineWrapping"},
			{ "label": "Auto Close Tags", "key": "autoCloseTags" },
			{ "label": "Auto Close Brackets", "key": "autoCloseBrackets" },
			{ "label": "Fold Gutter", "key": "foldGutter" },
			{ "label": "Show cursor when selecting", "key": "showCursorWhenSelecting" },
			{ "label": "Style active line", "key": "styleActiveLine"}
		];

		var localSettings = {
			"lineNumbers": true,
			"lineWrapping": false,
			"autoCloseTags": false,
			"autoCloseBrackets": false,
			"foldGutter": true,
			"showCursorWhenSelecting": false,
			"styleActiveLine": true
		};

		var storageSettings = JSON.parse(localStorage.getItem("editorsettings"));
		if (!storageSettings) {
			localStorage.setItem("editorsettings", JSON.stringify(localSettings));
		}
		var mergedSettings = Object.assign({}, localSettings, storageSettings);

		if (!editorInstance) {
			console.error("Editor instance not provided");
			return CreateSettingsTable("editorSettings", editorSettings);
		}

		for (var setting in mergedSettings) {
			editorInstance.setOption(setting, mergedSettings[setting] ? true : false);
		}

		return CreateSettingsTable("editorSettings", editorSettings);
	}

    function CreateAppearanceSettings() {

        var editorSelectedTheme = localStorage.getItem("editortheme");
        var toolbarSelectedTheme = localStorage.getItem("toolbartheme");
        var topToolbar = $("#topToolBar");
        var bottomToolbar = $(".dux-control-bar-bottom");

        cm.setOption("theme", editorSelectedTheme || "default");
        topToolbar.addClass(toolbarSelectedTheme);
        bottomToolbar.addClass(toolbarSelectedTheme);

        const editorThemes = [
            "3024-day", "3024-night", "abcdef", "ambiance", "base16-dark", "base16-light",
            "bespin", "blackboard", "cobalt", "colorforth", "darcula", "dracula", "duotone-dark", "duotone-light",
            "eclipse", "elegant", "erlang-dark", "gruvbox-dark", "hopscotch", "icecoder", "idea", "isotope", 
            "lesser-dark", "liquibyte", "lucario", "material", "material-darker", "material-palenight", 
            "material-ocean", "mbo", "mdn-like", "midnight", "monokai", "moxer", "neat", "neo", "night", "nord",
            "oceanic-next", "panda-syntax", "paraiso-dark", "paraiso-light", "pastel-on-dark", "railscasts", "rubyblue",
            "seti", "shadowfox", "solarized dark", "solarized light", "the-matrix", "tomorrow-night-bright", 
            "tomorrow-night-eighties", "ttcn", "twilight", "vibrant-ink", "xq-dark", "xq-light", "yeti", "yonce", "zenburn", "oceanic-dark"
        ];

        const toolbarThemes = ["Light", "Dark", "Material-Dark", "Lawrencium", "Purple", "Vista"];

        var editorThemeSelect = $("<select>", {
            "class": "editor-theme-select",
            "change": function(e) {
                cm.setOption("theme", e.currentTarget.value);
                localStorage.setItem("editortheme", e.currentTarget.value);
            }
        });

        var toolbarThemeSelect = $("<select>", {
            "class": "toolbar-theme-select",
            "change": function(e) {
                var previousTheme = localStorage.getItem("toolbartheme");
                var selectedTheme = e.currentTarget.value;
                topToolbar.removeClass(previousTheme).addClass(selectedTheme);
                bottomToolbar.removeClass(previousTheme).addClass(selectedTheme);
                localStorage.setItem("toolbartheme", selectedTheme);
            }
        });

        for (var i = 0; i < editorThemes.length; i++) {
            var themeOption = $("<option>", {
                    "value": editorThemes[i],
                    "text": editorThemes[i]
                })
                .attr("selected", editorThemes[i] == editorSelectedTheme);                
            editorThemeSelect.append(themeOption);
        }

        for (var i = 0; i < toolbarThemes.length; i++) {
            var themeOption = $("<option>", {
                    "value": toolbarThemes[i],
                    "text": toolbarThemes[i]
                })
                .attr("selected", toolbarThemes[i] == toolbarSelectedTheme);
            toolbarThemeSelect.append(themeOption);
        }

        var formControls = [
            { "label": "Editor", "control": editorThemeSelect },
            { "label": "Toolbar", "control": toolbarThemeSelect }
        ];

        return CreateHorizontalFormControl(formControls);
    }

    function CreateHorizontalFormControl(controls) {

        var form = $("<form>", {
            "class": "form-horizontal"
        });

        for (var i = 0; i < controls.length; i++) {
            var controlLabel = controls[i].label;
            var controlInput = controls[i].control;
            var controlGroup = $("<div>", {
                "class": "control-group"
            });
            var label = $("<label>", {
                "class": "control-label",
                "text": controlLabel
            });
            var controlContainer = $("<div>", {
                "class": "controls"
            });
            controlInput.addClass("input-block-level");
            controlContainer.append(controlInput);
            controlGroup.append(label);
            controlGroup.append(controlContainer);
            form.append(controlGroup);
        }

        return form;
    }

    function CreateKeybindingSettings() {

        var keybindingSettings = {
            MakeRows: {
                name: "Make rows",
                defaultKey: "Ctrl-1"
            },
            MakeCols: {
                name: "Make Cols",
                defaultKey: "Ctrl-2"
            },
            MakeChoices: {
                name: "Make Choices",
                defaultKey: "Ctrl-3"
            },
            MakeRowsMatchValues: {
                name: "Make rows match values",
                defaultKey: "Ctrl-4"
            },
            MakeColsMatchValues: {
                name: "Make cols match values",
                defaultKey: "Ctrl-5"
            },
            MakeChoicesMatchValues: {
                name: "Make choices match values",
                defaultKey: "Ctrl-6"
            },
            MakeRowsMatchLabel: {
                name: "Make rows match label",
                defaultKey: "Alt-1"
            },
            MakeColsMatchLabel: {
                name: "Make columns match label",
                defaultKey: "Alt-2"
            },
            MakeChoicesMatchLabel: {
                name: "Make choices match label",
                defaultKey: "Alt-3"
            },
            MakeRowsLowToHigh: {
                name: "Make rows lowest to highest",
                defaultKey: "Shift-Ctrl-1"
            },
            MakeColsLow: {
                name: "Make cols lowest to highest",
                defaultKey: "Shift-Ctrl-2"
            },
            MakeChoicesLowToHigh: {
                name: "Make choices lowest to highest",
                defaultKey: "Shift-Ctrl-3"
            },
            MakeRowsHighToLow: {
                name: "Make rows highest to lowest",
                defaultKey: "Shift-Ctrl-4"
            },
            MakeColsHighToLow: {
                name: "Make cols highest to lowest",
                defaultKey: "Shift-Ctrl-5"
            },
            MakeChoicesHighToLow: {
                name: "Make choices highest to lowest",
                defaultKey: "Shift-Ctrl-6"
            },
            ConvertToRows: {
                name: "Convert to rows",
                defaultKey: "F1"
            },
            ConvertToCols: {
                name: "Convert to cols",
                defaultKey: "F2"
            },
            ConvertToChoices: {
                name: "Convert to choices",
                defaultKey: "F3"
            },
            MakeCases: {
                name: "Make cases",
                defaultKey: "Alt-4"
            },
            AddValues: {
                name: "Add value attribute",
                defaultKey: "Ctrl-7"
            },
            RemoveValues: {
                name: "Remove value attribute",
                defaultKey: "Ctrl-8"
            },
            MakeRadio: {
                name: "Make radio",
                defaultKey: "Ctrl-R"
            },
            makeText: {
                name: "Make text",
                defaultKey: "Ctrl-E"
            },
            MakeTextArea: {
                name: "Make textarea",
                defaultKey: "Shift-Ctrl-E"
            },
            MakeSelect: {
                name: "Make select",
                defaultKey: "Ctrl-S"
            },
            MakeNumber: {
                name: "Make number",
                defaultKey: "Ctrl-Q"
            },
            MakeFloat: {
                name: "Make float",
                defaultKey: "Ctrl-M"
            },
            MakeCheckbox: {
                name: "Make checkbox",
                defaultKey: "Shift-Ctrl-C"
            },
            MakeDatePicker: {
                name: "Make datepicker",
                defaultKey: "Shift-Ctrl-D"
            },
            MakeSliderRating: {
                name: "Make slider rating",
                defaultKey: "Shift-Ctrl-S"
            },
            MakeGroups: {
                name: "Make groups",
                defaultKey: "Shift-Ctrl-G"
            },
            AssignGroup: {
                name: "Assign group",
                defaultKey: "Alt-A"
            },
            RemoveGroup: {
                name: "Remove group",
                defaultKey: "Alt-R"
            },
            WrapTag: {
                name: "Wrap with tag",
                defaultKey: "Alt-W"
            },
            ReverseString: {
                name: "Reverse string",
                defaultKey: "Alt-S"
            },
            MakeBlock: {
                name: "Make block",
                defaultKey: "Ctrl-B"
            },
            MakeLoop: {
                name: "Make loop",
                defaultKey: "Ctrl-L"
            },
            MakeHTML: {
                name: "Make HTML",
                defaultKey: "Ctrl-H"
            },
            MakeComment: {
                name: "Make comment",
                defaultKey: "Ctrl-I"
            },
            MakeCases: {
                name: "Make cases",
                defaultKey: "Alt-4"
            },
            MakePipe: {
                name: "Make pipe",
                defaultKey: "Ctrl-P"
            },
            MakeDefine: {
                name: "Make define",
                defaultKey: "Ctrl-D"
            }
        };

        return CreateHotkeySettingsTable("hotkeySettings", keybindingSettings);
    }

    function CreateHotkeySettingsTable(tableId, hotkeys) {

        var table = $("<table>", {
            "id": tableId,
            "class": "table table-striped"
        });

        for (var entry in hotkeys) {

            var setting = hotkeys[entry];
            var label = setting.name;
            var defaultKey = setting.defaultKey;

            var tableRow = $("<tr>", {
                "class": "table-row"
            });

            var cellLabel = $("<td>", {
                "text": label,
                "class": "cell-label"
            });

            var cellControl = $("<td>", {
                "class": "cell-control",
                "text": defaultKey
            });

            tableRow.append(cellLabel);
            tableRow.append(cellControl)
            table.append(tableRow);
        }
        return table;
    }

    function CreateOtherSettings() {
        //TODO: Implement other settings

        const controls = [
            { "label": "Radio comment", "name": "radioComment" },
            { "label": "Radio grid comment", "name": "radioGridComment" },
            { "label": "Checkbox comment", "name": "checkboxComment" },
            { "label": "Select comment", "name": "selectComment" },
            { "label": "Text comment", "name": "textComment" },
            { "label": "Textarea comment", "name": "textareaComment" },
            { "label": "Number comment", "name": "numberComment" },
            { "label": "Datepicker comment", "name": "datepickerComment" },
            { "label": "Sliderrating comment", "name": "sliderratingComment" }
        ];

        const default_1 = {
            "radioComment": "Select one",
            "radioGridComment": "Select one in each row",
            "checkboxComment": "Select all that apply",
            "selectComment": "",
            "textComment": "Please be as specific as possible",
            "textareaComment": "Please be as specific as possible",
            "numberComment": "Please enter a whole number",
            "datepickerComment": "Please select a date",
            "sliderratingComment": "Drag the slider to a point on the scale"
        }

        const default_2 = {
            "radioComment": "Please select one",
            "radioGridComment": "Please select one in each row",
            "checkboxComment": "Please select all that apply",
            "selectComment": "",
            "textComment": "Please be as specific as possible",
            "textareaComment": "Please be as specific as possible",
            "numberComment": "Please enter a whole number",
            "datepickerComment": "Please select a date",
            "sliderratingComment": "Drag the slider to a point on the scale"
        }

        const default_3 = {
            "radioComment": "${res.SR}",
            "radioGridComment": "${res.SRBrand}",
            "checkboxComment": "${res.MR}",
            "selectComment": "${res.SR}",
            "textComment": "${res.Open}",
            "textareaComment": "${res.Open}",
            "numberComment": "Please enter a whole number",
            "datepickerComment": "",
            "sliderratingComment": "${res.Slider}"
        }

        var defaultComments = [
            { "label": "Default Comments 1", "options": default_1, "readonly": true },
            { "label": "Default Comments 2", "options": default_2, "readonly": true },
            { "label": "Pure Profile Theme", "options": default_3, "readonly": false }
        ];

        var commentSettings = JSON.parse(localStorage.getItem("commentsettings"));

        //Create comment settings if not exists
        if(!commentSettings) {
            var setting = {};
            for(var i = 0; i < defaultComments.length; i++) {
                setting[i] = {
                    "name": defaultComments[i].label,
                    "selected": i == 0,
                    "options": defaultComments[i].options,
                    "readonly": true
                }
            }
            localStorage.setItem("commentsettings", JSON.stringify(setting));
        } else {
            for(var settings in commentSettings) {
                if(commentSettings[settings].selected) {
                    clips.options.comments = commentSettings[settings].options;
                    break;
                }
            }
        }

        var container = $("<div>", {
            "class": "other-settings-container"
        });

        //Create tab control for comment settings

        var tabMenus = ["comment_table_tab", "comment_form_tab"];

        var tabs = {
            "comment_table_tab": CreateCommentSettingsTable("commentSettingsTable", defaultComments),
            "comment_form_tab": CreateCommentForm(controls)
        };

        var tabControl = $("<div>", {
            "id": "comment-settings-tab-control",
            "class": "tab-control"
        });

        var tabList = $("<ul>", {
            "class": "nav nav-tabs"
        })
        .css({
            "display": "none"
        });

        var tabContent = $("<div>", {
            "class": "tab-content"
        });

        for(var i = 0; i < tabMenus.length; i++) {

            var list = $("<li>").toggleClass("active", i == 0);
            
            var toggle = $("<a>", {
                "href": "#" + tabMenus[i],
                "data-toggle": "tab",
                "text": tabMenus[i]
            });

            var fixedContainer = $("<div>", {
                "class": "fixed-container"
            });

            var content = $("<div>", {
                "id": tabMenus[i],
                "class": "tab-pane fade in"
            })
            .toggleClass("active", i == 0);

            list.append(toggle);
            fixedContainer.append(tabs[tabMenus[i]]);
            content.append(fixedContainer);
            tabList.append(list);
            tabContent.append(content);
        }

        tabControl.append(tabList);
        tabControl.append(tabContent);
        container.append(tabControl);

        return container;
    }   

    function CreateCommentSettingsTable(tableId, source) {
        //Create base container element
        var container = $("<div>", { 
            "class": "comment-settings-table-container"
        });
        //Create fixed container element
        var fixedContainer = $("<div>", { 
            "class": "fixed-container" 
        }).css({
            "max-height": "143px",
            "overflow": "auto"
        });
        //Create toolbar element
        var toolbarTable = CreateCommentSettingsToolbar();
        //Create comment table element
        var commentTable = CreateCommentTable();

        commentTable.append(LoadCommentSettings());
        fixedContainer.append(commentTable)
        container.append(toolbarTable);
        container.append(fixedContainer);
        return container;
    }

    function CreateCommentSettingsToolbar() {

        //Create toolbar table
        var toolbarTable = $("<table>", {
            "class": "table table-striped valign-middle"
        })
        .css({
            "margin": "0"
        });

        var tableHeader = $("<thead>", {
            "class": "table-header"
        });

        var tableHeaderRow = $("<tr>", {
            "class": "table-header-row"
        });

        var tableHeaderCellLabel = $("<td>", {
            "class": "table-header-cell",
        });

        var headerText = $("<p>", {
            "text": "Comment settings"
        });

        var tableHeaderCellControl = $("<td>", {
            "class": "table-header-cell",
        });

        var tableHeaderAddButton = $("<button>", {
            "class": "btn btn-primary pull-right",
            "type": "button",
            "text": "Create new",
            "click": function(e) {
                $("#tab_other .fixed-container").scrollTop(0);
                $("a[href=\"#comment_form_tab\"").click();
                $("#submitCommentButton").prop("disabled", false);
                $("#deleteCommentButton").toggle(false);
            }
        });
        tableHeaderCellLabel.append(headerText);
        tableHeaderCellControl.append(tableHeaderAddButton);
        tableHeaderRow.append(tableHeaderCellLabel);
        tableHeaderRow.append(tableHeaderCellControl);
        tableHeader.append(tableHeaderRow);
        toolbarTable.append(tableHeader);

        return toolbarTable;
    }

    function CreateCommentTable() {

        var table = $("<table>", {
            "id": "comment_settings_table",
            "class": "table table-striped"
        });

        return table;
    }

    function CreateCommentForm(source) {

        var form = $("<form>", {
            "id": "comment_form"
        });


        form.on("submit", function(e) {
            e.preventDefault();
            var commentForm = $("#comment_form");
            var commentId = $("#commentId").val();
            var commentTable = $("#comment_settings_table");
            var commentTableToggle = $("a[href='#comment_table_tab'");
            var name = $("#comment_name").val();
            var data = commentForm.serializeArray();
            var settings = JSON.parse(localStorage.getItem("commentsettings"));
            var hasId = commentId && settings[commentId];
            var id = hasId ? commentId : Object.entries(settings).length + 1;

            var props = {};
            for(var i = 0; i < data.length; i++) {
                props[data[i].name] = data[i].value;
            }

            if(hasId) {
                settings[id].name = name;
                settings[id].options = props;
            } else {
                settings[id] = { 
                    "name": name, 
                    "options": props, 
                    "readonly": false 
                }
            }
            localStorage.setItem("commentsettings", JSON.stringify(settings));
            commentTable.empty().append(LoadCommentSettings);
            toastr.success("", "Settings Saved", {"toastClass": "toast-top-center"})
            commentTableToggle.click();
            $("#comment_form input").each(function(index, element) {
                element.value = null;
                element.readOnly = false;
            });
        })

        var settingNameContainer = $("<div>", {
            "class": "row-fluid"
        });

        var settingNameLabel = $("<label>", {
            "class": "control-label span12",
            "text": "Setting name"
        });

        var settingNameInput = $("<input>", {
            "id": "comment_name",
            "class": "span12",
            "type": "text",
            "required": "required"
        });

        var hiddenInput = $("<input>", {
            "id": "commentId",
            "type": "hidden"
        });

        var commentFormNav = $("<div>", {
            "class": "flex-nav"
        });


        var buttonRow = $("<div>", {
            "class": "form-actions"
        });

        var deleteButton = $("<button>", {
            "id": "deleteCommentButton",
            "class": "btn btn-danger",
            "type": "button",
            "text": "Delete",
            "click": function(e) {
                var commentId = $("#commentId").val();
                var localSettings = JSON.parse(localStorage.getItem("commentsettings"));
                var commentTable = $("#comment_settings_table");
                var commentTableToggle = $("a[href='#comment_table_tab'");
                delete localSettings[commentId];
                localStorage.setItem("commentsettings", JSON.stringify(localSettings));
                commentTable.empty().append(LoadCommentSettings());
                toastr.success("", "Settings Saved", {"toastClass": "toast-top-center"});
                commentTableToggle.click();
                $("#comment_form input").each(function(index, element) {
                    element.value = null;
                    element.readOnly = false;
                });
            }
        })
        .css({
            "margin-right": "5px"
        });

        var submitButton = $("<button>", {
            "id": "submitCommentButton",
            "class": "btn btn-primary pull-right",
            "type": "submit",
            "text": "Save"
        });

        var cancelButton = $("<button>", {
            "type": "button",
            "class": "btn pull-right",
            "text": "Cancel",
            "click": function(e) { 
                $("a[href=\"#comment_table_tab\"").click();
                $("#comment_form input").each(function(index, element) {
                    element.value = null;
                    element.readOnly = false;
                });
            }
        })
        .css({
            "margin-right": "5px"
        });

        var header = $("<h4>", {
            "text": "Setup instruction text"
        });

        commentFormNav.append(header);
        settingNameContainer.append(settingNameLabel);
        settingNameContainer.append(settingNameInput);
        form.append(commentFormNav);
        form.append(hiddenInput);
        form.append(settingNameContainer);

        for(var i = 0; i < source.length; i++) {
            var row = $("<div>", {
                "class": "row-fluid"
            });

            var label = $("<div>", {
                "class": "control-label span12",
                "text": source[i].label,
                "for": source[i].name,
            });

            var input = $("<input>", {
                "id": source[i].name,
                "name": source[i].name,
                "class": "span12",
                "type": "text",
            });

            row.append(label);
            row.append(input);
            form.append(row);
        } 
        buttonRow.append(deleteButton);
        buttonRow.append(submitButton);
        buttonRow.append(cancelButton);
        form.append(buttonRow);

        return form;
    }

    function LoadCommentSettings() {

        var commentSettings = JSON.parse(localStorage.getItem("commentsettings"));
        var filterSelected = Object.keys(commentSettings).filter(x => commentSettings[x].selected);
        var selected = filterSelected.length ? filterSelected.pop() : 0;
        clips.options.comments = commentSettings[selected].options;

        var tableBody = $("<tbody>", {
            "class": "table-body"
        });

        for(var settings in commentSettings) {

            var tableRow = $("<tr>", {
                "class": "table-row"
            });

            var cellControl = $("<td>", {
                "class": "cell-control"
            });

            var cellRadio = $("<label>", {
                "class": "radio"
            });

            var cellRadioInput = $("<input>", {
                "name": "selectComment",
                "type": "radio",
                "value": settings,
                "checked": selected == settings,
                "change": function(e) {
                    for(var key in commentSettings) {
                        var entries = commentSettings[key];
                        entries.selected = (key == e.currentTarget.value)
                    }
                    clips.options.comments = commentSettings[e.currentTarget.value].options;
                    localStorage.setItem("commentsettings", JSON.stringify(commentSettings));
                }
            });

            var cellRadioLabel = $("<span>", {
                "text": ""
            });

            var cellLabel = $("<td>", {
                "class": "cell-label"
            });

            var cellLink = $("<a>", {
                "href": "#",
                "data-value": settings,
                "class": "cell-link",
                "text": commentSettings[settings].name,
                "click": function(e) {
                    //Get current target value
                    var localSettings = JSON.parse(localStorage.getItem("commentsettings"));
                    var key = $(this).data("value");
                    var commentId = $("#commentId");
                    var commentName = $("#comment_name");
                    var submitButton = $("#submitCommentButton");
                    var deleteCommentButton = $("#deleteCommentButton");
                    var commentFormToggle = $("a[href='#comment_form_tab']");
                    var fixedContainer = $("#tab_other .fixed-container");
                    $("#comment_form input:text").each(function(index, element) {
                        element.value = localSettings[key].options[element.name];
                        element.readOnly = localSettings[key].readonly;
                    });
                    commentId.val(key);
                    commentName.val(localSettings[key].name).change();
                    submitButton.prop("disabled", localSettings[key].readonly);
                    deleteCommentButton.toggle(!localSettings[key].readonly);
                    commentFormToggle.click();
                    fixedContainer.scrollTop(0);
                }
            });

            cellRadio.append(cellRadioInput);
            cellRadio.append(cellRadioLabel);
            cellControl.append(cellRadio);
            cellLabel.append(cellLink);
            tableRow.append(cellControl);
            tableRow.append(cellLabel);
            tableBody.append(tableRow);
        }

        return tableBody;
    }

    function CreateHelpModal() {

        var container = $("<div>", {
            "class": "row-fluid"
        });

        var treeContainer = $("<div>", {
            "class": "span4 tree-view-pane"
        });

        var contentContainer = $("<div>", {
            "class": "span8 content-view-pane"
        });

        var loaderContainer = $("<div>", {
            "class": "loader-container"
        });

        var loaderGif = $("<img>", {
            "class": "loader-gif",
            "src": "https://faviconer.net/preloaders/47/Glass%20lines.gif"
        });

        var iframe = $("<iframe>", {
            "class": "content-view-iframe",
            "src": ""
        });

        iframe.on("load", function(e) {
            console.log("finished loading");
            loaderContainer.hide();
        });

        iframe.on("error", function(e) {
            loaderContainer.hide();
        });

        var helpTree = $("<div>", {
            "id": "helpTree"
        });

        helpTree.fancytree({
            "source": [{
                    "title": "Getting Started", 
                    "folder": true, 
                    "expanded": true,
                    "children": [
                        {"title": "Welcome"},
                        {"title": "Interface"},
                        {"title": "Settings"}
                    ]
                }, {
                    "title": "Commands",
                    "folder": true,
                    "expanded": true,
                    "children": [
                        {
                            "title": "Rows",
                            "folder": true,
                            "expanded": true,
                            "children": [
                                {"title": "Make rows", "url": "https://r9ndzp386pvmlmpqsqlzzw-on.drv.tw/Website/Help/doc-make-rows.html"},
                                {"title": "Make rows match label", url: "https://r9ndzp386pvmlmpqsqlzzw-on.drv.tw/Website/Help/doc-make-rows-match-label.html"},
                                {"title": "Make rows match values", url: "https://r9ndzp386pvmlmpqsqlzzw-on.drv.tw/Website/Help/doc-make-rows-match-values.html"},
                                {"title": "Make rows ascending", url: "https://r9ndzp386pvmlmpqsqlzzw-on.drv.tw/Website/Help/doc-make-rows-ascending.html"},
                                {"title": "Make rows descending", url: "https://r9ndzp386pvmlmpqsqlzzw-on.drv.tw/Website/Help/doc-make-rows-descending.html"}
                            ]
                        }, {
                            "title": "Columns",
                            "folder": true,
                            "expanded": true,
                            "children": [
                                {"title": "Make cols"},
                                {"title": "Make cols match label"},
                                {"title": "Make cols match values"},
                                {"title": "Make cols ascending"},
                                {"title": "Make cols descending"}
                            ]
                        }, {
                            "title": "Choices",
                            "folder": true,
                            "expanded": true,
                            "children": [
                                {"title": "Make choices"},
                                {"title": "Make choices match label"},
                                {"title": "Make choices match values"},
                                {"title": "Make choices ascending"},
                                {"title": "Make choices descending"}
                            ]
                        }, {
                            "title": "Questions",
                            "folder": true,
                            "expanded": true,
                            "children": [
                                {"title": "Make Radio"},
                                {"title": "Make Checkbox"},
                                {"title": "Make Select"},
                                {"title": "Make Number"},
                                {"title": "Make Text"},
                                {"title": "Make Textarea"},
                                {"title": "Make Float"},
                                {"title": "Make Datepicker"},
                                {"title": "Make Slider rating"},
                                {"title": "Make HTML"},
                                {"title": "Make Block"},
                                {"title": "Make Loop"}
                            ]
                        }
                    ]
                }
            ],
            "activate": function(event, data) {
                var node = data.node;
                console.log(node.data.url);
                if(node.data.url) {
                    loaderContainer.show();
                    $(".content-view-iframe").prop("src", node.data.url);
                }
            }
        });
        loaderContainer.append(loaderGif);
        contentContainer.append(loaderContainer);
        contentContainer.append(iframe);
        treeContainer.append(helpTree);
        container.append(treeContainer);
        container.append(contentContainer);
        var modal = CreateModal("helpModal", "Help", container, null);
        modal.addClass("big-modal");
        $("body").append(modal);
    }



    $(window).on("load", function() {
        CreateSettingsModal();
        CreateHelpModal();
        cm.refresh();
        if(!editor.errorState) {
            $(".xmledit-splashscreen").hide();
            $(".xmledit-container").show();
        }
        $(window).resize();
    });

})(window, jQuery);
